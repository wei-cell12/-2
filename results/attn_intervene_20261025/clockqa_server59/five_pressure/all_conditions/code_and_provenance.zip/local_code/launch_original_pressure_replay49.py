"""One-shot guarded launch after all intervention generation has naturally exited."""
import fcntl,json,os,shutil,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
RUNTIME='/home/linxin/miniconda3/envs/vllm_new/bin/python'
def alive(pid):
 p=Path('/proc')/str(pid)/'stat';return p.exists() and p.read_text().split(') ',1)[1][0]!='Z'
def write(p,d):
 t=p.with_name(p.name+'.tmp.'+str(os.getpid()));t.write_text(json.dumps(d,indent=2)+'\n');t.replace(p)
def main():
 out=ROOT/'original_pressure_spatial';out.mkdir(exist_ok=True)
 with (out/'launch.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  receipt=out/'launch_receipt.json'
  if receipt.exists():print(receipt.read_text());return
  q=json.loads((ROOT/'queue.json').read_text());assert not q.get('failure')
  selected=json.loads((ROOT/'luna_approved_candidates.json').read_text())['items'];assert len(selected)==49
  if any(q['interventions'][i['id']]['status']!='complete' for i in selected):
   print(json.dumps(dict(status='waiting_for_generation_to_finish',nothing_launched=True)));return
  for w in range(4):
   wr=ROOT/'workers'/str(w);s=json.loads((wr/'job_state.json').read_text());assert not (wr/'failure.json').exists()
   if alive(s['pid']) or s['status']!='worker_complete':
    print(json.dumps(dict(status='waiting_for_natural_exit',worker=w,nothing_launched=True)));return
  apps=subprocess.run(['nvidia-smi','--query-compute-apps=gpu_uuid,pid','--format=csv,noheader,nounits'],capture_output=True,text=True,check=True,timeout=20).stdout
  cards=subprocess.run(['nvidia-smi','--query-gpu=index,uuid,memory.free','--format=csv,noheader,nounits'],capture_output=True,text=True,check=True,timeout=20).stdout
  cardmap={int(a[0]):a for a in [[x.strip() for x in line.split(',')] for line in cards.splitlines()]}
  for w in range(4):
   a=json.loads((ROOT/'workers'/str(w)/'allocation_request.json').read_text());card=cardmap[w];assert card[1]==a['uuids'][0]
   if int(card[2])<73728 or any(line.split(',')[0].strip()==card[1] for line in apps.splitlines()):
    print(json.dumps(dict(status='waiting_for_free_card',card=w,nothing_launched=True)));return
  workers=[]
  for w in range(4):
   original=ROOT/'workers'/str(w);dest=out/'workers'/str(w);dest.mkdir(exist_ok=True,parents=True)
   for f in original.glob('*.py'):shutil.copy2(f,dest/f.name)
   for f in ['config.json','allocation_request.json']:shutil.copy2(original/f,dest/f)
   (dest/'source').symlink_to(original/'source',target_is_directory=True) if not (dest/'source').exists() else None
   shutil.copy2(ROOT/'replay_original_pressure49.py',dest/'replay_original_pressure49.py')
   a=json.loads((dest/'allocation_request.json').read_text());env=os.environ.copy();env.update(CLOCKQA_INTERVENTION_ROOT=str(ROOT),CLOCKQA_WORKER_INDEX=str(w),CUDA_VISIBLE_DEVICES=a['uuids'][0],PYTHONNOUSERSITE='1',PYTHONUNBUFFERED='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false')
   probe=subprocess.run([RUNTIME,'-c',"import ctypes; n=ctypes.CDLL('libcuda.so.1').cuInit(0); print(n); raise SystemExit(n!=0)"],env=env,capture_output=True,text=True,timeout=25);assert probe.returncode==0 and probe.stdout.strip()=='0'
   # Immediate second process check before starting this worker.
   fresh=subprocess.run(['nvidia-smi','--query-compute-apps=gpu_uuid,pid','--format=csv,noheader,nounits'],capture_output=True,text=True,check=True,timeout=20).stdout
   assert not any(line.split(',')[0].strip()==a['uuids'][0] for line in fresh.splitlines())
   with (dest/'runner.log').open('ab') as log:proc=subprocess.Popen([RUNTIME,'-u',str(dest/'replay_original_pressure49.py')],cwd=dest,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   workers.append(dict(worker=w,gpu=w,pid=proc.pid,root=str(dest),log=str(dest/'runner.log')))
   write(receipt,dict(status='exact_saved_token_spatial_replay',workers=workers,time_unix=time.time(),new_baseline_answers_generated=False,exit_after_save=True))
  print(receipt.read_text())
if __name__=='__main__':main()
