"""Resume every already-audited eligible pressure condition, retaining saved work."""
import json,subprocess,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent
REMOTE='/mnt/sdi/linxin/proofwriter_runs/clockqa-scaleup-20261025/interventions'

SCRIPT=r'''
import fcntl,hashlib,json,os,py_compile,shutil,subprocess,sys,time
from pathlib import Path
import numpy as np
root=Path(REMOTE);payload=PAYLOAD
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def alive(pid):
 p=Path('/proc')/str(pid)/'stat'
 return p.exists() and p.read_text().split(') ',1)[1][0]!='Z'
def write(p,v):
 t=p.with_name(p.name+'.next');t.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');t.replace(p)
with (root/'launch.lock').open('a') as launch_lock:
 fcntl.flock(launch_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 prior_launch=json.loads((root/'launch_receipt.json').read_text())
 assert not any(alive(w['pid']) for w in prior_launch['workers']),'Healthy workers must not be duplicated'
 holder=json.loads((root.parent/'intervention_transition/temporary_reservation_state.json').read_text())
 assert holder['status']=='reserved' and alive(holder['pid'])
 assert {x['index'] for x in holder['cards']}=={0,1,2,3}
 old_selection=json.loads((root/'luna_approved_candidates.json').read_text());selection=payload['selection']
 assert selection['items'][:len(old_selection['items'])]==old_selection['items']
 before_queue=json.loads((root/'queue.json').read_text())
 completed_ids={key for key,e in before_queue['interventions'].items() if e['status']=='complete'}
 completed_items=[x for x in selection['items'] if x['id'] in completed_ids]
 assert len(completed_items)==17 and selection['items'][:17]==completed_items
 old_selection=dict(old_selection,items=completed_items)
 assert len({x['id'] for x in selection['items']})==len(selection['items'])==49
 assert selection['neutral_correct_conditions']==110
 for item in selection['items']:
  for kind in ['neutral','pressure']:
   assert sha(item[kind+'_record'])==item[kind+'_source_sha256']
   r=json.loads(Path(item[kind+'_record']).read_text());assert r['image_sha256']==item['image_sha256'] and r['input_ids']
  assert sha(item['image'])==item['image_sha256']
 archive=root/'attempts'/('before_all_pressure_conditions_'+str(time.time_ns()));archive.mkdir(parents=True)
 for name,expected in payload['original_files'].items():
  assert sha(root/name)==hashlib.sha256(expected.encode()).hexdigest(),('Previously deployed algorithm changed',name)
 with (root/'queue.lock').open('a') as queue_lock:
  fcntl.flock(queue_lock,fcntl.LOCK_EX)
  q=json.loads((root/'queue.json').read_text());assert not q.get('failure')
  assert all(e['status']=='complete' for e in q['interventions'].values())
  for name in ['queue.json','luna_approved_candidates.json','config.json','request.json','job_state.json','cpu_preflight.json','intervention_queue.py','launch_clock_interventions.py']:
   p=root/name
   if p.exists():shutil.copy2(p,archive/name)
  q['exited_workers']={};q['workers']=4;q['resume_scope']='all eligible question_x_pressure conditions';q['resume_unix']=time.time()
  write(root/'queue.json',q);write(root/'luna_approved_candidates.json',selection)
  config=json.loads((root/'config.json').read_text());config.update(transition_deadline_unix=holder['deadline'],selection_unit='question_x_pressure',eligible_conditions=49,unique_selected_images=17,neutral_correct_pressure_conditions=110)
  write(root/'config.json',config);write(root/'request.json',config)
  for name,code in payload['files'].items():
   (root/name).write_text(code);py_compile.compile(str(root/name),doraise=True)
  sys.path.insert(0,str(root));os.environ['CLOCKQA_INTERVENTION_ROOT']=str(root)
  import intervention_queue
  assert intervention_queue.review_valid(),'Existing six-reply numerical and raw-output review must remain valid'
  from references import construct,validate_replay
  # All new pressure conditions share a previously checked neutral sequence with one of the saved 17.
  old_by_question={x['question_id']:x for x in old_selection['items']}
  reused_checks=[]
  for item in selection['items'][len(old_selection['items']):]:
   old=old_by_question[item['question_id']]
   assert item['neutral_source_sha256']==old['neutral_source_sha256'] and item['image_sha256']==old['image_sha256']
   old_meta=json.loads((root/'reference_meta'/(old['id']+'.json')).read_text())
   source=Path(old_meta['source']);assert sha(source)==old_meta['source_sha256']
   with np.load(source) as z:d={k:z[k] for k in z.files}
   rec=json.loads(Path(item['neutral_record']).read_text());check=validate_replay(d,dict(rec,id=item['id']))
   native_path=root/'records'/rec['record_id']/'attention.npz'
   with np.load(native_path) as z:native=z['generation_masses'][...,0].astype(np.float64)
   replay=d['pos_image_mass'].astype(np.float64);assert native.shape==replay.shape
   corr=float(np.corrcoef(native.ravel(),replay.ravel())[0,1]);mad=float(np.abs(native-replay).mean());assert corr>=.99 and mad<=.01
   check.update(corr=corr,mad=mad,rows_mismatch=0,source=str(source),source_sha256=sha(source),reused=True,reused_neutral_question=old['question_id'])
   dest=root/'references'/(item['id']+'.npz');meta=root/'reference_meta'/(item['id']+'.json')
   if dest.exists():
    assert meta.exists() and json.loads(meta.read_text())['reference_sha256']==sha(dest)
   else:
    assert not meta.exists(),'Reference metadata exists without array'
    m=construct(item['id'],d,dest);m.update(source=str(source),source_sha256=sha(source),reference_sha256=sha(dest));write(meta,m)
   reused_checks.append(check)
  with (root/'neutral_replay_checks_all_conditions.jsonl').open('a') as f:
   for c in reused_checks:f.write(json.dumps(c)+'\n')
  remaining=len(selection['items'])-len(old_selection['items'])
  required=remaining*3*96*4610*13*4+2*1024**3
  assert shutil.disk_usage(root/'traces').free>required,('Insufficient trace space',required)
  runtime='/home/linxin/miniconda3/envs/vllm_new/bin/python'
  env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES='',PYTHONNOUSERSITE='1',HF_HUB_OFFLINE='1')
  tests=subprocess.run([runtime,str(root/'numerical_tests.py')],cwd=root,env=env,capture_output=True,text=True,timeout=60)
  (root/'numerical_tests_all_conditions.log').write_text(tests.stdout+tests.stderr);assert tests.returncode==0,tests.stderr
  gate=json.loads((root/'cpu_preflight.json').read_text());gate.update(passed=True,config_sha256=sha(root/'config.json'),source_mapping_verified=49,resumed_conditions=remaining,neutral_replay_reused=len(reused_checks),disk_required_remaining=required,selection_only_change=True,time_unix=time.time())
  write(root/'cpu_preflight.json',gate)
  for i in range(4):
   wr=root/'workers'/str(i);wa=archive/'workers'/str(i);wa.mkdir(parents=True)
   for name in ['model_ready.json','job_state.json','allocation_request.json','runner.log','module_check.json']:
    p=wr/name
    if p.exists():p.rename(wa/name)
   assert not (wr/'failure.json').exists()
   for name in ['intervention_queue.py','config.json','request.json','cpu_preflight.json']:shutil.copy2(root/name,wr/name)
  (root/'launch_receipt.json').rename(archive/'launch_receipt.json')
  write(root/'all_conditions_resume_preflight.json',dict(approved_conditions=49,reused_complete_conditions=len(old_selection['items']),remaining_conditions=remaining,remaining_replies=remaining*3,review_reused=True,neutral_reference_reuse_checks=len(reused_checks),algorithm_unchanged=True,archive=str(archive),time_unix=time.time()))
print(json.dumps(dict(prepared=True,conditions=49,reused=17,remaining=32,archive=str(archive))),flush=True)
runtime='/home/linxin/miniconda3/envs/vllm_new/bin/python'
launch=subprocess.run([runtime,str(root/'launch_clock_interventions.py')],cwd=root,capture_output=True,text=True,timeout=90)
print(launch.stdout);print(launch.stderr);raise SystemExit(launch.returncode)
'''

def main():
 selection=json.loads((BASE/'clock_intervention_candidates.json').read_text())
 deployed=json.loads((BASE/'clock_intervention_deployment_payload.json').read_text())['files']
 names=['workflow_common.py','generation_common.py','run_intervention.py','intervention.py','references.py','numerical_tests.py','clock_rules.py','sdpa_math_decode.py','run_clock_intervention_worker.py']
 payload=dict(selection=selection,original_files={n:deployed[n] for n in names},files={n:(BASE/n).read_text() for n in ['intervention_queue.py','launch_clock_interventions.py']})
 script=SCRIPT.replace('REMOTE',repr(REMOTE)).replace('PAYLOAD',repr(payload))
 sys.path.insert(0,str(BASE.parent/'server_connection'));from transport import command
 p=subprocess.run(command('/home/linxin/miniconda3/envs/vllm_new/bin/python -'),input=script,text=True,capture_output=True,timeout=180)
 (BASE/'all_conditions_resume_receipt.txt').write_text(p.stdout+p.stderr);print(p.stdout);print(p.stderr);raise SystemExit(p.returncode)
if __name__=='__main__':main()
