"""Finite handoff: save current valid interventions, then reuse original baselines."""
import subprocess,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent
SCRIPT=r'''
import fcntl,hashlib,json,os,py_compile,shutil,subprocess,time
from pathlib import Path
root=Path('/mnt/sdi/linxin/proofwriter_runs/clockqa-scaleup-20261025/interventions')
def alive(pid):
 p=Path('/proc')/str(pid)/'stat'
 return p.exists() and p.read_text().split(') ',1)[1][0]!='Z'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
 t=p.with_name(p.name+'.next');t.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');t.replace(p)
with (root/'launch.lock').open('a') as launch_lock:
 fcntl.flock(launch_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 receipt=json.loads((root/'launch_receipt.json').read_text());pids=[w['pid'] for w in receipt['workers']]
 assert pids==[945218,945227,945254,945273]
 for w in receipt['workers']:
  proc=Path('/proc')/str(w['pid'])
  if alive(w['pid']):
   assert proc.stat().st_uid==os.getuid()
   assert str(Path(w['root'])/'run_clock_intervention_worker.py') in (proc/'cmdline').read_bytes().replace(b'\0',b' ').decode()
 selection=json.loads((root/'all_49_luna_approved_candidates.json').read_text());assert len(selection['items'])==49
 # A finite phase handoff only; never signal, interrupt, or restart a healthy intervention.
 deadline=time.time()+900
 while any(alive(pid) for pid in pids):
  q=json.loads((root/'queue.json').read_text());assert not q.get('failure'),q.get('failure')
  assert time.time()<deadline,'Current phase did not finish within handoff bound'
  time.sleep(1)
 archive=root/'attempts'/('completed_cases_before_original_baseline_reuse_'+str(time.time_ns()));archive.mkdir(parents=True)
 with (root/'queue.lock').open('a') as queue_lock:
  fcntl.flock(queue_lock,fcntl.LOCK_EX)
  q=json.loads((root/'queue.json').read_text());assert not q.get('failure') and all(x['status']=='complete' for x in q['interventions'].values())
  completed=len(q['interventions']);assert completed>=17
  for name in ['queue.json','luna_approved_candidates.json','config.json','request.json','launch_receipt.json','job_state.json','cpu_preflight.json','run_clock_intervention_worker.py']:
   p=root/name
   if p.exists():shutil.copy2(p,archive/name)
  write(root/'luna_approved_candidates.json',selection)
  baseline=[]
  for item in selection['items']:
   p=Path(item['pressure_record']);assert sha(p)==item['pressure_source_sha256'];r=json.loads(p.read_text())
   assert r['image_sha256']==item['image_sha256']
   baseline.append(dict(id=item['id'],question_id=item['question_id'],ptype=item['ptype'],baseline_kind='original_native_pressure',generated_now=False,source_path=str(p),source_sha256=sha(p),image_sha256=item['image_sha256'],pressure_message=item['pressure_message'],joint_correct=False,semantic_judgment_source=selection['annotations_sha256']))
  write(root/'original_pressure_baselines.json',dict(unit='question_x_pressure',conditions=49,correct=0,source='same Luna original pressure annotations',items=baseline))
  q['exited_workers']={};q['workers']=4;q['baseline_policy']='reuse_original_native_pressure';write(root/'queue.json',q)
  c=json.loads((root/'config.json').read_text());c.update(intervention_methods=['restore_E','restore_rand'],baseline_policy='reuse_original_native_pressure',primary_baseline_file=str(root/'original_pressure_baselines.json'),historical_lambda0_role='separate numerical validation only; not primary baseline')
  write(root/'config.json',c);write(root/'request.json',c)
  (root/'run_clock_intervention_worker.py').write_text(WORKER_CODE);py_compile.compile(str(root/'run_clock_intervention_worker.py'),doraise=True)
  gate=json.loads((root/'cpu_preflight.json').read_text());gate.update(config_sha256=sha(root/'config.json'),baseline_regeneration=False);write(root/'cpu_preflight.json',gate)
  for w in receipt['workers']:
   wr=Path(w['root']);dest=archive/'workers'/str(w['worker']);dest.mkdir(parents=True)
   for name in ['model_ready.json','job_state.json','allocation_request.json','runner.log','module_check.json']:
    p=wr/name
    if p.exists():p.rename(dest/name)
   assert not (wr/'failure.json').exists()
   for name in ['run_clock_intervention_worker.py','config.json','request.json','cpu_preflight.json']:shutil.copy2(root/name,wr/name)
  (root/'launch_receipt.json').unlink() # Archived bytes above; all four old workers have naturally exited.
 transition=root.parent/'intervention_transition';oldholder=json.loads((transition/'temporary_reservation_state.json').read_text());assert not alive(oldholder['pid'])
 shutil.copytree(transition,archive/'completed_transition');shutil.rmtree(transition)
 transition.mkdir();(transition/'intervention_transition_reservation.py').write_text(RESERVATION_CODE)
 runtime='/home/linxin/miniconda3/envs/vllm_new/bin/python'
 r=subprocess.run([runtime,str(transition/'intervention_transition_reservation.py')],capture_output=True,text=True,timeout=70)
 (archive/'new_reservation_receipt.txt').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
 holder=json.loads((transition/'temporary_reservation_state.json').read_text());assert holder['status']=='reserved' and {x['index'] for x in holder['cards']}=={0,1,2,3}
 c=json.loads((root/'config.json').read_text());c['transition_deadline_unix']=holder['deadline'];write(root/'config.json',c);write(root/'request.json',c)
 for i in range(4):
  for name in ['config.json','request.json']:shutil.copy2(root/name,root/'workers'/str(i)/name)
 write(root/'original_baseline_reuse_receipt.json',dict(original_conditions=49,methods=['restore_E','restore_rand'],completed_intervention_conditions_reused=completed,remaining_conditions=49-completed,remaining_replies=2*(49-completed),baseline_regeneration_disabled=True,healthy_models_not_interrupted=True,archive=str(archive),time_unix=time.time()))
print(json.dumps(dict(prepared=True,original_baselines_reused=49,complete_conditions=completed,remaining_conditions=49-completed)),flush=True)
r=subprocess.run([runtime,str(root/'launch_clock_interventions.py')],cwd=root,capture_output=True,text=True,timeout=90)
print(r.stdout);print(r.stderr);raise SystemExit(r.returncode)
'''
def main():
 script=SCRIPT.replace('WORKER_CODE',repr((BASE/'run_clock_intervention_worker.py').read_text())).replace('RESERVATION_CODE',repr((BASE/'intervention_transition_reservation.py').read_text()))
 compile(script,'remote_baseline_handoff','exec')
 sys.path.insert(0,str(BASE.parent/'server_connection'));from transport import command
 p=subprocess.run(command('python3 -'),input=script,text=True,capture_output=True,timeout=1080)
 (BASE/'original_baseline_two_arm_handoff_receipt.txt').write_text(p.stdout+p.stderr);print(p.stdout);print(p.stderr);raise SystemExit(p.returncode)
if __name__=='__main__':main()
