"""Deploy only small code/config/manifests over the existing shared SSH session."""
import hashlib, json, subprocess, sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
WORKSPACE = BASE.parent.parent
OLD = WORKSPACE / 'work/clockqa_attn_intervene_server59_20261025/qwen38_math_decode'
REMOTE_ROOT = '/mnt/sdi/linxin/proofwriter_runs/clockqa-scaleup-20261025'
REMOTE_OLD = '/mnt/sdi/linxin/proofwriter_runs/clockqa-attn-intervene-20261025/qwen38_math_decode'

def main():
    originals = [json.loads(line) for line in (OLD / 'catalog.jsonl').read_text().splitlines() if line.strip()]
    assert len(originals) == 62
    cached = json.loads((OLD / 'config.json').read_text())
    current = json.loads((BASE / 'prior_config_identity_check.json').read_text())
    config = current['config']
    assert {key for key in set(cached) | set(config) if cached.get(key) != config.get(key)} == {'model_identity_sha256'}
    identities = list(json.loads((BASE / 'prior_model_identity_check.json').read_text()).values())
    assert len(identities) == 2
    assert identities[0]['sha256'] == config['model_identity_sha256']
    assert {key for key in set(identities[0]['body']) | set(identities[1]['body']) if identities[0]['body'].get(key) != identities[1]['body'].get(key)} == {'time_unix'}
    templates = config['pressure_templates']
    assert len(templates) == 5
    rows = []
    for original in originals:
        for kind, template in templates.items():
            row = dict(original)
            row.update(question_id=original['item_id'],
                       item_id=original['item_id'] + '--' + kind,
                       pressure_type=kind, pressure_text=template.format(wrong=original['wrong_answer']),
                       selection_basis='All62 original ClockQA questions crossed with all5 fixed pressure templates; not310 independent images')
            rows.append(row)
    body = ''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in rows)
    (BASE / 'catalog.jsonl').write_text(body)
    config.update(experiment_id='clockqa-server59-five-pressure-20261025',
        questions=62, pressure_conditions=310, planned=372,
        prior_experiment_root=REMOTE_OLD, prior_config_sha256=current['sha256'],
        catalog_sha256=hashlib.sha256(body.encode()).hexdigest(),
        pressure_counts={kind:62 for kind in templates}, selected_indices=list(range(62)),
        remote_root=REMOTE_ROOT, gpu=[0,1,2,3], prior_observation_outputs_reused=True,
        neutral_reuse=62, pressure_reuse=62, new_pressure_generations=248,
        pressure_only_generation_stage=True,
        annotation_policy='Same Luna; answer and full explanation jointly correct; unresolved/range ambiguity retained; paper tolerance is separate')
    (BASE / 'config.json').write_text(json.dumps(config, ensure_ascii=False, indent=2) + '\n')
    summary=json.loads((OLD.parent/'luna_audit/summary.json').read_text())
    assert summary['source_snapshot_sha256']=='c7274d6582b00cd53f7100051bd33f2ae05ae32df2e63ef3e0b0ad0c0c494cf4'
    eligibility=[json.loads(line) for line in (OLD.parent/'luna_audit/eligibility.jsonl').read_text().splitlines() if line.strip()]
    correct=sorted(row['id'] for row in eligibility if row['neutral_joint_correct'] is True)
    assert len(correct)==22
    copied=['generation_common.py','workflow_common.py','observe.py','screening.py','sdpa_math_decode.py']
    files={name:(OLD/name).read_text() for name in copied}
    expected={name:hashlib.sha256(text.encode()).hexdigest() for name,text in files.items()}
    files.update({name:(BASE/name).read_text() for name in ['scaleup_queue.py','prepare_scaleup.py','run_scaleup_worker.py','launch_scaleup.py','task.md','catalog.jsonl','config.json']})
    payload=dict(files=files,expected_old_code_sha256=expected,neutral_correct_priority=correct,
                 luna_source_sha256=summary['source_snapshot_sha256'])
    (BASE/'deployment_payload.json').write_text(json.dumps(payload,ensure_ascii=False))
    remote=r'''
import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
payload=json.loads(sys.stdin.read())
root=Path('/mnt/sdi/linxin/proofwriter_runs/clockqa-scaleup-20261025')
old=Path('/mnt/sdi/linxin/proofwriter_runs/clockqa-attn-intervene-20261025/qwen38_math_decode')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not (root/'launch_receipt.json').exists(),'Inspect previous receipt before redeployment'
for name,digest in payload['expected_old_code_sha256'].items():assert sha(old/name)==digest,(name,'Source changed')
assert sha(old/'config.json')==json.loads(payload['files']['config.json'])['prior_config_sha256']
data=Path('/mnt/sdb/linxin/proofwriter_runs/clockqa-five-pressure-20261025')
data.mkdir(parents=True,exist_ok=True)
config=json.loads(payload['files']['config.json'])
# Bound this finite screening stage from uncompressed array shapes, rather
# than requiring an arbitrary20GiB. Full intervention storage is checked later.
raw_bound=248*((config['max_new_tokens']+1024)*len(config['layers'])*config['heads']*5*4+1024**2)
required=int(raw_bound*1.25)+2*1024**3
disk=dict(stage='248 pressure observations',free=shutil.disk_usage(data).free,
 max_prefill_queries=1024,uncompressed_bound_bytes=raw_bound,
 required_bytes_with_25pct_plus_2GiB_headroom=required,
 full_intervention_requires_separate_disk_check=True)
(root/'disk_budget.json').write_text(json.dumps(disk,indent=2)+'\n')
assert disk['free']>required,('Not enough room for bounded stage',disk)
for name,text in payload['files'].items():
 p=root/name
 if p.exists():assert p.read_text()==text,(name,'Existing content differs')
 else:p.write_text(text)
for name,target in [('images',old/'images'),('source',old/'source'),('records',data/'records')]:
 if name=='records':target.mkdir(exist_ok=True)
 p=root/name
 if p.exists():assert p.resolve()==target.resolve()
 else:p.symlink_to(target,target_is_directory=True)
(root/'live').mkdir(exist_ok=True)
shutil.copy2(root/'config.json',root/'request.json')
runtime='/home/linxin/miniconda3/envs/vllm_new/bin/python'
env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES='',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',PYTHONNOUSERSITE='1')
with (root/'prepare.log').open('ab') as output:
 result=subprocess.run([runtime,'-u',str(root/'prepare_scaleup.py')],cwd=root,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=240)
if result.returncode:raise RuntimeError((root/'prepare.log').read_text()[-5000:])
gate=json.loads((root/'cpu_preflight.json').read_text());assert gate['passed']
catalog=[json.loads(line) for line in (root/'catalog.jsonl').read_text().splitlines()]
reuse={row['case_id']:row for row in json.loads((root/'reused_pressure_sources.json').read_text())}
order=[row['item_id'] for row in sorted(catalog,key=lambda row:(row['question_id'] not in payload['neutral_correct_priority'],row['question_id'],list(json.loads((root/'config.json').read_text())['pressure_templates']).index(row['pressure_type'])))]
entries={}
for row in catalog:
 key=row['item_id'];prior=reuse.get(key)
 entries[key]=dict(question_id=row['question_id'],pressure_type=row['pressure_type'],status='complete' if prior else 'pending',reused=bool(prior))
 if prior:entries[key].update(source_record=prior['source_record'],source_sha256=prior['source_sha256'])
assert len(entries)==310 and sum(e['status']=='pending' for e in entries.values())==248
queue=dict(order=order,entries=entries,unique_questions=62,pressure_conditions=310,exited_workers=[],failure=None,luna_source_sha256=payload['luna_source_sha256'],eligibility_by_same_luna_only=True,time_unix=time.time())
(root/'queue.json').write_text(json.dumps(queue,ensure_ascii=False,indent=2)+'\n')
codefiles=[name for name in payload['files'] if name.endswith('.py') and name not in ['prepare_scaleup.py','launch_scaleup.py']]
for i in range(4):
 worker=root/'workers'/str(i);worker.mkdir(parents=True,exist_ok=True)
 for name in codefiles:shutil.copy2(root/name,worker/name)
 for name in ['config.json','request.json']:shutil.copy2(root/name,worker/name)
 for name in ['images','source','records','live','catalog.jsonl','tokenized_inputs.jsonl','cpu_preflight.json']:
  p=worker/name
  if p.exists():assert p.resolve()==(root/name).resolve()
  else:p.symlink_to(root/name,target_is_directory=(root/name).is_dir())
print(json.dumps(dict(deployed=True,root=str(root),cpu_preflight=gate,queue_pending=248,workers=4,code_sha256={name:sha(root/name) for name in payload['files'] if name.endswith('.py')})),flush=True)
'''
    sys.path.insert(0,str(WORKSPACE/'work/server_connection'))
    from transport import command
    # A small public source program reads a JSON payload from a temporary file;
    # no model weights, environment archives, credentials, or source tokens move.
    import base64
    encoded=base64.b64encode(json.dumps(payload,ensure_ascii=False).encode()).decode()
    wrapper='import sys,io,base64\nsys.stdin=io.StringIO(base64.b64decode('+repr(encoded)+').decode())\nexec('+repr(remote)+')\n'
    result=subprocess.run(command('/usr/bin/python3.10 -'),input=wrapper,text=True,capture_output=True,timeout=280)
    (BASE/'deployment_receipt.txt').write_text(result.stdout+'\n'+result.stderr)
    print(result.stdout);print(result.stderr[-3000:]);raise SystemExit(result.returncode)

if __name__=='__main__':main()
