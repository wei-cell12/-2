"""Single finite reservation-to-model handoff; never a scheduled monitor."""
import fcntl, json, os, subprocess, time
from pathlib import Path
from scaleup_queue import write

ROOT = Path(__file__).resolve().parent
RUNTIME = '/home/linxin/miniconda3/envs/vllm_new/bin/python'

def alive(pid):
    p = Path('/proc') / str(pid) / 'stat'
    return p.exists() and p.read_text().split(') ', 1)[1][0] != 'Z'

def main():
    with (ROOT / 'launcher.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        receipt = ROOT / 'launch_receipt.json'
        if receipt.exists():
            old = json.loads(receipt.read_text())
            if any(alive(row['pid']) for row in old['workers']):
                print(json.dumps(dict(status='already_running', **old)), flush=True)
                return
            raise RuntimeError('Prior workers exited; inspect saved state before retry')
        assert json.loads((ROOT / 'cpu_preflight.json').read_text())['passed']
        holders = [ROOT, ROOT / 'reservation_gpu3']
        states = [json.loads((p / 'temporary_reservation_state.json').read_text()) for p in holders]
        assert all(s['status'] == 'reserved' and alive(s['pid']) and time.time() < s['deadline'] for s in states)
        cards = {c['index']: c for s in states for c in s['cards']}
        assert set(cards) == {0, 1, 2, 3}
        allowed = [s['pid'] for s in states]
        for p in holders:
            (p / 'handoff_reservation_memory').touch()
        deadline = time.time() + 45
        while True:
            current = [json.loads((p / 'temporary_reservation_state.json').read_text()) for p in holders]
            if all(s['status'] == 'handoff_small_context_only' for s in current): break
            assert time.time() < deadline, current
            time.sleep(.25)
        workers = []
        for gpu in [0, 1, 2, 3]:
            r = ROOT / 'workers' / str(gpu)
            allocation = dict(physical_gpus=[gpu], uuids=[cards[gpu]['uuid']],
                max_memory={'0': '70GiB', 'cpu': '128GiB'}, all_gpu=True,
                temporary_holder_pids=allowed, time_unix=time.time())
            write(r / 'allocation_request.json', allocation)
            env = os.environ.copy()
            env.update(CLOCKQA_PARENT_ROOT=str(ROOT), CLOCKQA_WORKER_INDEX=str(gpu),
                CUDA_VISIBLE_DEVICES=cards[gpu]['uuid'], PATHVQA_PHYSICAL_GPU=str(gpu),
                PYTHONNOUSERSITE='1', PYTHONUNBUFFERED='1', HF_HUB_OFFLINE='1',
                TRANSFORMERS_OFFLINE='1', TOKENIZERS_PARALLELISM='false')
            probe = subprocess.run([RUNTIME, '-c',
                "import ctypes; d=ctypes.CDLL('libcuda.so.1'); n=d.cuInit(0); print(n); raise SystemExit(n!=0)"],
                env=env, capture_output=True, text=True, timeout=25)
            assert probe.returncode == 0 and probe.stdout.strip() == '0', (gpu, probe.stdout, probe.stderr)
            with (r / 'runner.log').open('ab') as stream:
                process = subprocess.Popen([RUNTIME, '-u', str(r / 'run_scaleup_worker.py')],
                    cwd=r, env=env, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
            workers.append(dict(worker=gpu, gpu=gpu, uuid=cards[gpu]['uuid'], pid=process.pid,
                                root=str(r), log=str(r / 'runner.log')))
            # Preserve receipts immediately, even if a later card cannot start.
            write(receipt, dict(workers=workers, intended_gpus=[0, 1, 2, 3],
                phase='five_pressure_generation', time_unix=time.time(),
                no_recurring_monitor=True, same_model_precision_sampling=True,
                finite_exit_after_queue=True, holder_release='after model-ready receipts'))
        write(ROOT / 'job_state.json', dict(status='four_gpu_five_pressure_running',
            workers=workers, unique_questions=62, pressure_conditions=310,
            reused_pressure=62, new_pressure=248, reused_neutral=62, time_unix=time.time()))
        print(json.dumps(json.loads(receipt.read_text())), flush=True)

if __name__ == '__main__': main()

