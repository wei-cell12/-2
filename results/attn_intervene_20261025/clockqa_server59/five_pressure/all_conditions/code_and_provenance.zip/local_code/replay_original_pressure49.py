"""Exact saved-token spatial replay; never generate or change any baseline answer."""
import fcntl,hashlib,json,os,sys,time,traceback
from pathlib import Path
PARENT=Path(os.environ['CLOCKQA_INTERVENTION_ROOT']);HERE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,d):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);t=p.with_name(p.name+'.tmp.'+str(os.getpid()));t.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');t.replace(p)
def reduce(item,path,check):
 import numpy as np
 with np.load(PARENT/'references'/(item['id']+'.npz')) as z:
  heads=z['heads'].astype(bool);nr=z['E_r'].astype(float);mask=z['E_mask'].astype(bool);grid=z['grid_hw'].tolist()
 assert heads.sum()==96
 rows={}
 with np.load(path) as z:
  assert z['grid_hw'].tolist()==grid
  for s,stage in enumerate(['think','answer']):
   a=z[stage].astype(float);mass=a.sum(-1,keepdims=True)
   if not (mass[heads]>0).all():
    rows[stage]=dict(available=False,reason='saved-token phase has no image mass; retained, not scored as wrong');continue
   pr=np.divide(a,mass,out=np.zeros_like(a),where=mass>0);n=nr[s][heads];p=pr[heads];k=int(mask[s][heads][0].sum())
   ni=np.argsort(-n,axis=-1,kind='stable')[:,:k];pi=np.argsort(-p,axis=-1,kind='stable')[:,:k]
   rows[stage]=dict(available=True,neutral_map=n.mean(0).tolist(),pressure_map=p.mean(0).tolist(),difference_map=(p-n).mean(0).tolist(),neutral_E_share=float((n*mask[s][heads]).sum(-1).mean()),pressure_E_share=float((p*mask[s][heads]).sum(-1).mean()),top20_retention=float(np.mean([len(set(x)&set(y))/k for x,y in zip(ni,pi)])),unit='equal mean of96 heads; stage-average then image-internal normalization')
 return dict(id=item['id'],question_id=item['question_id'],pressure_type=item['ptype'],grid_hw=grid,stages=rows,validation=check,array=dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path)),baseline_kind='original_native_pressure',saved_token_replay_only=True,new_answer_generated=False)
def cached(item):
 roots=[PARENT/'original_pressure_spatial/arrays',Path('/mnt/sdi/linxin/proofwriter_runs/clockqa-attn-intervene-20261025/qwen38_math_decode/observation_replay')]
 for root in roots:
  for marker in root.glob('*__pressure_validation.json'):
   c=json.loads(marker.read_text())
   if c.get('source_record_sha256')!=item['pressure_source_sha256']:continue
   p=marker.with_name(marker.name.replace('_validation.json','.npz'))
   assert c['ok'] and c['array_sha256']==sha(p)
   return p,c
 return None
def main():
 import numpy as np
 from PIL import Image
 from workflow_common import backend
 worker=int(os.environ['CLOCKQA_WORKER_INDEX']);selected=json.loads((PARENT/'luna_approved_candidates.json').read_text())['items'];assert len(selected)==49
 resultroot=PARENT/'original_pressure_spatial';(resultroot/'arrays').mkdir(exist_ok=True,parents=True)
 tasks=selected[worker::4];pending=[]
 for item in tasks:
  out=resultroot/(item['id']+'.json')
  if out.exists():
   old=json.loads(out.read_text());assert old['validation']['source_record_sha256']==item['pressure_source_sha256'];assert sha(old['array']['path'])==old['array']['sha256'];continue
  found=cached(item)
  if found:write(out,reduce(item,*found))
  else:pending.append(item)
 if not pending:
  write(HERE/'job_state.json',dict(status='replay_complete',pid=os.getpid(),model_loaded=False,model_released=True,time_unix=time.time()));return
 # No allocation while any generation model is still active or another process owns this card.
 import subprocess
 allocation=json.loads((HERE/'allocation_request.json').read_text());card=allocation['physical_gpus'][0];assert card in [0,1,2,3]
 apps=subprocess.run(['nvidia-smi','--query-compute-apps=gpu_uuid,pid','--format=csv,noheader,nounits'],capture_output=True,text=True,check=True).stdout
 assert not any(line.split(',')[0].strip()==allocation['uuids'][0] for line in apps.splitlines())
 b=backend();sys.path.insert(0,str(HERE/'source'));from symexp.attn import replay_item,save_npz
 for item in pending:
  source=Path(item['pressure_record']);assert sha(source)==item['pressure_source_sha256'];rec=json.loads(source.read_text());assert sha(item['image'])==rec['image_sha256']==item['image_sha256']
  write(HERE/'job_state.json',dict(status='replaying_saved_pressure_tokens',id=item['id'],pid=os.getpid(),new_answer_generated=False,time_unix=time.time()))
  b.model.model.rope_deltas=None
  d=replay_item(b,rec['input_ids']+rec['output_ids'],len(rec['input_ids']),Image.open(item['image']).convert('RGB'),selfcheck=3)
  assert d['layer_ids'].tolist()==list(range(3,64,4)) and int(d['count_prefill_end'])==1
  assert int(d['count_think'])+int(d['count_answer'])+1==len(rec['output_ids'])
  selfcheck=float(np.max(d['selfcheck_max_abs_diff']));assert selfcheck<.05
  with np.load(source.parent/'attention.npz') as z:native=z['generation_masses'][...,0].astype(float)
  actual=d['pos_image_mass'].astype(float);assert native.shape==actual.shape
  corr=float(np.corrcoef(native.ravel(),actual.ravel())[0,1]);mad=float(np.abs(native-actual).mean());assert corr>=.99 and mad<=.01,(item['id'],corr,mad)
  dest=resultroot/'arrays'/(item['id']+'__pressure.npz');assert not dest.exists()
  save_npz(str(dest),d)
  check=dict(ok=True,id=item['id'],source_record_sha256=sha(source),selfcheck_max=selfcheck,corr=corr,mad=mad,counts={s:int(d['count_'+s]) for s in ['prefill_end','think','answer']},array_sha256=sha(dest),saved_token_replay_only=True,new_answer_generated=False)
  write(dest.with_name(dest.stem+'_validation.json'),check);write(resultroot/(item['id']+'.json'),reduce(item,dest,check));del d
 del b
 import gc,torch
 gc.collect();torch.cuda.empty_cache();write(HERE/'job_state.json',dict(status='replay_complete',pid=os.getpid(),model_released=True,time_unix=time.time()))
if __name__=='__main__':
 with (HERE/'runner.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  try:main()
  except BaseException as e:
   write(HERE/'failure.json',dict(error=repr(e),pid=os.getpid(),time_unix=time.time()));(HERE/'failure_traceback.log').write_text(traceback.format_exc());raise
