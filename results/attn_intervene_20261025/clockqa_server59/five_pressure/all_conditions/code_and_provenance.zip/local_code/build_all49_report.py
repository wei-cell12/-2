"""Build an explicitly partial or final fixed-49 report from frozen saved outputs."""
import collections,csv,hashlib,html,json,math,shutil,statistics
from datetime import datetime
from zoneinfo import ZoneInfo
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont
BASE=Path(__file__).resolve().parent;AUDIT=BASE/'all_conditions/luna_audit';OUT=BASE/'all_conditions/results'
OUT.mkdir(exist_ok=True);(OUT/'heatmaps').mkdir(exist_ok=True);(OUT/'cases').mkdir(exist_ok=True)
def load(p):return json.loads(p.read_text())
def rows(p):return [json.loads(s) for s in p.read_text().splitlines() if s.strip()] if p.exists() else []
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
packet=load(AUDIT/'source_snapshot.json');data=load(OUT/'derived_attention.json')
assert data['source_snapshot_sha256']==sha(AUDIT/'source_snapshot.json'),'Refetch attention for current frozen packet'
fixed=packet['fixed_case_ids'];assert len(fixed)==len(set(fixed))==49
baseline={r['id']:r for r in packet['original_pressure_baselines']};assert set(baseline)==set(fixed)
raw={r['record_key']:r for r in packet['records']};assert len(raw)==len(packet['records'])
annotations=rows(AUDIT/'prior_34_intervention_annotations.jsonl')+rows(AUDIT/'new_intervention_annotations.jsonl')
ann={r['record_key']:r for r in annotations};assert len(ann)==len(annotations)
for k,a in ann.items():
 r=raw[k];assert a['model']=='gpt-6-luna'
 if a['joint_correct'] is True:assert a['answer_correct'] is True and a['explanation_correct'] is True,('Inconsistent joint annotation',k)
 for f in ['source_sha256','raw_output_sha256','image_sha256']:assert a[f]==r[f]
 assert hashlib.sha256(r['raw_output'].encode()).hexdigest()==r['raw_output_sha256']
 assert sha(Path(r['local_image_path']))==r['image_sha256']
 for q in [a['final_answer_quote']]+a['explanation_quotes']:assert q in r['raw_output']
for b in baseline.values():
 assert not b['generated_now'] and b['baseline_kind']=='original_native_pressure'
 assert b['neutral_joint_correct'] is True and b['original_pressure_joint_correct'] is False
 assert hashlib.sha256(b['original_pressure_raw_output'].encode()).hexdigest()==b['pressure_raw_output_sha256']
methods=['restore_E','restore_rand'];names={'restore_E':'关键区域干预','restore_rand':'随机区域干预'}
names['native_comparison']='中性与原始压力区域对照'
spatial=load(OUT/'original_pressure_spatial.json') if (OUT/'original_pressure_spatial.json').exists() else dict(records=[],completed=0)
spatial_byid={r['id']:r for r in spatial['records']}
for i,r in spatial_byid.items():
 assert r['validation']['source_record_sha256']==baseline[i]['pressure_source_sha256'] and not r['new_answer_generated']
def key(i,m):return 'clockqa5_intervention:'+i+'__'+m
def status(i,m):
 a=ann.get(key(i,m));return '待生成' if key(i,m) not in raw else '待审核' if a is None else '恢复正确' if a['joint_correct'] is True else '仍错误' if a['joint_correct'] is False else '未解决'
summary=dict(scope='fixed49 question × original pressure;17 unique images',fixed_conditions=49,unique_images=17,original_native_baseline=dict(correct=0,incorrect=49,unresolved=0,reused=True,regenerated=False),methods={},native_attention={},intervention_attention={},source_snapshot_sha256=sha(AUDIT/'source_snapshot.json'),snapshot_unix=data['snapshot_unix'])
for m in methods:
 rr=[r for r in raw.values() if r['method']==m];aa=[a for a in ann.values() if a['method']==m]
 summary['methods'][m]=dict(saved=len(rr),reviewed=len(aa),correct=sum(a['joint_correct'] is True for a in aa),incorrect=sum(a['joint_correct'] is False for a in aa),unresolved=sum(a['joint_correct'] is None for a in aa),awaiting_review=len(rr)-len(aa),awaiting_generation=49-len(rr),answer_only_correct=sum(a['answer_correct'] is True for a in aa),recovered_ids=[a['id'] for a in aa if a['joint_correct'] is True])
summary['complete_conditions']=sum(all(key(i,m) in raw for m in methods) for i in fixed)
summary['original_pressure_spatial']=dict(completed=len(spatial_byid),target=49,new_baseline_answers_generated=False,stages={})
for stage in ['think','answer']:
 v=[r['stages'][stage] for r in spatial_byid.values() if r['stages'][stage]['available']]
 if v:summary['original_pressure_spatial']['stages'][stage]=dict(n=len(v),neutral_E_share=statistics.mean(r['neutral_E_share'] for r in v),pressure_E_share=statistics.mean(r['pressure_E_share'] for r in v),top20_retention=statistics.mean(r['top20_retention'] for r in v),unit='equal96-head mean; stage-average then image-internal normalization; equal condition weighting')
summary['all_reviewed']=all(summary['methods'][m]['reviewed']==49 for m in methods)
allocations=data['model_allocations']
assert all(all(k.startswith('cuda:') for k in a['actual_parameter_devices']) for a in allocations)
summary['runtime']=dict(model=data['config']['model_dir'],torch=allocations[0]['torch'],transformers=allocations[0]['transformers'],dtype=allocations[0]['dtype'],physical_gpus=[0,1,2,3],cpu_offload=False,last_two_arm_generation_phase_start_unix=data.get('launch',{}).get('time_unix'),last_two_arm_generation_phase_end_unix=data['queue']['updated_unix'],note='last two-arm continuation only; historical reused outputs have their own earlier logs')
if spatial_byid:summary['original_pressure_spatial']['validation']=dict(sdpa_max=max(r['validation']['selfcheck_max'] for r in spatial_byid.values()),correlation_min=min(r['validation']['corr'] for r in spatial_byid.values()),mad_max=max(r['validation']['mad'] for r in spatial_byid.values()))
summary['conservation_max']=max(r['metrics'][k] for r in raw.values() for k in ['image_diff_max','text_diff_max','row_diff_max'])
assert summary['conservation_max']<1e-3
for m in methods:
 summary['intervention_attention'][m]={}
 for stage in ['think','answer']:
  v=[r['metrics']['by_stage'][stage] for r in raw.values() if r['method']==m and r['metrics']['by_stage'].get(stage)]
  assert all(r['region_after']>=r['region_before'] for r in v)
  summary['intervention_attention'][m][stage]={k:statistics.mean(r[k] for r in v) for k in ['region_before','region_after','mean_delta']}
  summary['intervention_attention'][m][stage].update(n=len(v),unit='fraction of image attention; selected96 head-token mean within condition; equal condition weight')
for stage in ['think','answer']:
 summary['native_attention'][stage]={}
 for cond in ['neutral','pressure']:
  v=[p[cond]['stages'][stage]['image_mass'] for p in data['native_paired_totals']]
  valid=[x for x in v if x is not None]
  summary['native_attention'][stage][cond]=dict(mean=statistics.mean(valid),n=len(valid),unit='fraction of all attention;16 layers ×24 heads ×generated tokens; neutral repeated once per pressure condition')
if summary['all_reviewed']:
 pairs={}
 for ma,mb in [('original_native','restore_E'),('original_native','restore_rand'),('restore_E','restore_rand')]:
  left=[];right=[];unresolved=[]
  for i in fixed:
   a=False if ma=='original_native' else ann[key(i,ma)]['joint_correct'];b=ann[key(i,mb)]['joint_correct']
   if a is None or b is None:unresolved.append(i);continue
   if a and not b:left.append(i)
   if b and not a:right.append(i)
  n=len(left)+len(right);p=min(1,2*sum(math.comb(n,j) for j in range(min(len(left),len(right))+1))/2**n) if n else 1
  pairs[ma+'_vs_'+mb]=dict(left_only_correct=left,right_only_correct=right,discordant=n,exact_two_sided_p=p,unresolved=unresolved,inference_limit='conditions share17 images; ordinary condition-level paired p assumes independence and is descriptive')
 summary['pairs']=pairs
summary['pressure_breakdown']={}
for pt in ['belief','statement','authority','social','conviction']:
 ids=[i for i in fixed if baseline[i]['pressure_type']==pt]
 summary['pressure_breakdown'][pt]=dict(conditions=len(ids),**{m:dict(reviewed=sum(key(i,m) in ann for i in ids),correct=sum(ann.get(key(i,m),{}).get('joint_correct') is True for i in ids)) for m in methods})
font=lambda n:ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial Unicode.ttf',n)
def color(v,limit,diff=False):
 t=np.clip(v/max(limit,1e-14),-1 if diff else 0,1);t=np.sign(t)*np.sqrt(abs(t))
 if diff:
  end=np.where(t[...,None]>=0,np.array([215,40,35]),np.array([30,90,210]));return np.uint8(255*(1-abs(t[...,None]))+end*abs(t[...,None]))
 anchors=np.array([[25,15,65],[72,30,105],[139,44,107],[204,71,75],[248,143,57],[252,244,160]],float);u=t*5;i=np.minimum(u.astype(int),4);w=(u-i)[...,None]
 return np.uint8(anchors[i]*(1-w)+anchors[i+1]*w)
def render(c,m):
 image=Image.open(BASE/'luna_audit/images'/(c['question_id']+'.jpg')).convert('RGB');pw=270;ih=round(pw*image.height/image.width);gap=18;left=24;top=100;rh=ih+98
 canvas=Image.new('RGB',(4*pw+3*gap+2*left,top+2*rh+80),'white');d=ImageDraw.Draw(canvas);gh,gw=c['grid_hw'];thumb=image.resize((pw,ih),Image.Resampling.LANCZOS)
 d.text((left,14),c['id']+' · '+names[m],font=font(25),fill='#17233a')
 d.text((left,55),'原始已保存token的精确回放；每行统一色标，红增蓝减。' if m=='native_comparison' else '实际生成轨迹中的修改前后；每行统一色标，红增蓝减。',font=font(19),fill='#46566e')
 for s,phase in enumerate(['思考','回答']):
  y=top+s*rh;d.text((left,y),phase,font=font(22),fill='#17233a')
  if m=='native_comparison':
   stage=['think','answer'][s];r=c['stages'][stage]
   if not r['available']:
    d.text((left,y+50),'原序列本阶段没有可用区域质量；保留并标记缺失。',font=font(19),fill='#46566e');continue
   before=np.array(r['neutral_map']).reshape(gh,gw);after=np.array(r['pressure_map']).reshape(gh,gw)
  else:before=np.array(c['groups'][m]['before'][s]['map']).reshape(gh,gw);after=np.array(c['groups'][m]['after'][s]['map']).reshape(gh,gw)
  maps=[None,before,after,after-before];vmax=max(before.max(),after.max());dm=max(abs(after-before).max(),1e-14)
  labels=['原图','中性原序列','原始压力序列','压力−中性'] if m=='native_comparison' else ['原图','同轨迹：修改前','同轨迹：修改后','修改后−前']
  for col,(arr,label) in enumerate(zip(maps,labels)):
   x=left+col*(pw+gap);d.text((x,y+30),label,font=font(19),fill='#17233a');tile=thumb
   if arr is not None:tile=Image.blend(thumb,Image.fromarray(color(arr,dm if col==3 else vmax,col==3)).resize(thumb.size,Image.Resampling.NEAREST),.65)
   canvas.paste(tile,(x,y+60))
   if arr is not None:d.text((x,y+ih+64),'±%.3f pp/patch'%(dm*100) if col==3 else '0–%.3f %%/patch'%(vmax*100),font=font(16),fill='#46566e')
 d.text((left,top+2*rh),'96头等权；阶段内先平均，再按图像内归一化；与逐token区域份额的权重不同。',font=font(17),fill='#46566e')
 d.text((left,top+2*rh+30),'E为中性高注意力top20%，非人工证据标注。'+('复用原回答token，不生成新基线。' if m=='native_comparison' else '此图为实际干预trace。'),font=font(17),fill='#46566e')
 path=OUT/'heatmaps'/(c['id']+'__'+m+'.png');canvas.save(path);return path.name
maps={}
for c in data['cases']:
 for m in methods:
  if m in c['groups']:maps[(c['id'],m)]=render(c,m)
for c in spatial_byid.values():maps[(c['id'],'native_comparison')]=render(c,'native_comparison')
esc=lambda s:html.escape(str(s))
style='<style>body{max-width:1200px;margin:30px auto;padding:0 24px;font:17px system-ui;line-height:1.65;color:#17233a}table{border-collapse:collapse}td,th{border:1px solid #ddd;padding:8px 14px}img{max-width:100%}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:15px system-ui;background:#f5f7fa;padding:18px}summary{padding:12px;background:#edf1f7;cursor:pointer;margin:5px 0}small{color:#526079}</style>'
def page(title,body):return '<!doctype html><meta charset="utf-8"><title>'+esc(title)+'</title>'+style+body
when=datetime.fromtimestamp(data['snapshot_unix'],ZoneInfo('Asia/Shanghai')).strftime('%Y-%m-%d %H:%M:%S')
trajectory_path=AUDIT/'trajectory_annotations.jsonl'
summary['trajectory_records']=len(rows(trajectory_path))
summary['report_complete']=summary['all_reviewed'] and len(spatial_byid)==49 and summary['trajectory_records']==98
state='最终结果' if summary['report_complete'] else '生成与语义审核完成；区域对照整理中' if summary['all_reviewed'] else '阶段结果（尚未全部完成）'
body='<h1>ClockQA固定49个压力样本：'+state+'</h1><p>更新时间：'+when+'（北京时间）。49个“题目×压力”条件，来自17张不同图片；各自使用原先导致答错的同一种压力和原提示。49份原始压力回答直接复用，没有重新生成基线，没有按图片去重。</p>'
body+='<p>已完成两组干预：<b>'+str(summary['complete_conditions'])+' / 49个样本</b>。同一个Luna逐图读完整回答；答案与完整解释均正确才计为恢复，格式异常单独记录。</p><table><tr><th>组别</th><th>已保存</th><th>已审核</th><th>正确／恢复</th><th>错误</th><th>未解</th><th>待审核</th><th>待生成</th></tr><tr><td>原始压力基线</td><td>49</td><td>49</td><td>0</td><td>49</td><td>0</td><td>0</td><td>0</td></tr>'
for m in methods:
 r=summary['methods'][m];body+='<tr><td>'+names[m]+'</td>'+''.join('<td>'+str(r[k])+'</td>' for k in ['saved','reviewed','correct','incorrect','unresolved','awaiting_review','awaiting_generation'])+'</tr>'
body+='</table><p>未生成或未审核的输出不计为错误；阶段恢复数不是最终49例的结果。历史额外λ0输出只保留作数值验证，未混入本表。</p><p><a href="summary.json">可复算统计</a> · <a href="items.csv">逐样本表</a> · <a href="array_manifest.json">远端数组路径、大小与SHA</a></p>'
if summary['all_reviewed']:
 body+='<h2>配对结果</h2><table><tr><th>比较</th><th>前者独对</th><th>后者独对</th><th>discordant</th><th>精确双侧p</th></tr>'
 for pair,label in [('original_native_vs_restore_E','原始压力 → 关键区域'),('original_native_vs_restore_rand','原始压力 → 随机区域'),('restore_E_vs_restore_rand','关键区域 vs 随机区域')]:
  r=summary['pairs'][pair];body+=f'<tr><td>{label}</td><td>{len(r["left_only_correct"])}</td><td>{len(r["right_only_correct"])}</td><td>{r["discordant"]}</td><td>{r["exact_two_sided_p"]:.8f}</td></tr>'
 body+='</table><p>49个条件共享17张图片，条件级McNemar p按条件独立假定计算，仅作描述；原始压力组还是按错误结果选入的子集，不能将p直接解释为总体推广或独立49图的显著性证据。</p><h2>五种原压力分别恢复多少</h2><table><tr><th>原压力类型</th><th>固定条件数</th><th>关键区域恢复</th><th>随机区域恢复</th></tr>'
 for pt,r in summary['pressure_breakdown'].items():body+=f'<tr><td>{pt}</td><td>{r["conditions"]}</td><td>{r["restore_E"]["correct"]}</td><td>{r["restore_rand"]["correct"]}</td></tr>'
 body+='</table>'
body+='<h2>注意力的变化</h2><p>原始中性与压力的图像总注意力使用原始生成数组。49条件等权，中性参照按对应压力重复配对。</p><table><tr><th>阶段</th><th>中性图像总量</th><th>原始压力图像总量</th><th>差值</th></tr>'
for s,label in [('think','思考'),('answer','回答')]:
 n=summary['native_attention'][s]['neutral']['mean'];p=summary['native_attention'][s]['pressure']['mean'];body+=f'<tr><td>{label}</td><td>{n*100:.2f}%</td><td>{p*100:.2f}%</td><td>{(p-n)*100:+.2f}个百分点</td></tr>'
body+='</table><p>下表为干预目标区域占图像注意力的份额，各样本选中96头逐token均值再等权；它与上表的图像总量分母不同。E组目标为中性top20%区域，随机组目标为非E随机区域；随机对照并非等搬移剂量。</p><table><tr><th>组别／阶段</th><th>已保存样本数</th><th>修改前</th><th>修改后</th><th>搬移Δ</th></tr>'
for m in methods:
 for s,label in [('think','思考'),('answer','回答')]:
  r=summary['intervention_attention'][m][s];body+=f'<tr><td>{names[m]}／{label}</td><td>{r["n"]}</td><td>{r["region_before"]*100:.2f}%</td><td>{r["region_after"]*100:.2f}%</td><td>{r["mean_delta"]*100:.2f}个百分点</td></tr>'
body+='</table><p>干预热图来自实际生成trace；中性与原始压力区域图来自原回答token的精确回放，已完成'+str(len(spatial_byid))+' / 49例。不使用额外λ0热图替代。注意力增加本身不等于识别变正确，以逐例文本审核为准。</p>'
if spatial_byid:
 body+='<h2>原始压力把区域分布变到了哪里</h2><table><tr><th>阶段</th><th>中性E区域份额</th><th>原始压力E区域份额</th><th>top20%区域重合率</th></tr>'
 for stage,label in [('think','思考'),('answer','回答')]:
  r=summary['original_pressure_spatial']['stages'].get(stage)
  if r:body+=f'<tr><td>{label}（{r["n"]}例）</td><td>{r["neutral_E_share"]*100:.2f}%</td><td>{r["pressure_E_share"]*100:.2f}%</td><td>{r["top20_retention"]*100:.2f}%</td></tr>'
 body+='</table><p>此表为每头阶段平均后再按图像内归一化、96头等权，各条件再等权；不是逐token区域均值。逐例红蓝图显示具体patch的变化；区域重合率也按各头的top20%集合求交。E不是人工证据标注。</p>'
body+='<h2>全部49个样本</h2><table><tr><th>样本与原压力</th><th>关键区域</th><th>随机区域</th></tr>'
neutral={r['question_id']:r for r in packet['neutral_records']}
trajectory={r['record_key']:r for r in rows(AUDIT/'trajectory_annotations.jsonl')}
for ident in fixed:
 b=baseline[ident];detail='<p><a href="../index.html">返回49例总表</a></p><h1>'+esc(ident)+'</h1><p>标准时间：'+esc(b['gold'])+'；用户主张：'+esc(b['claim'])+'</p><p>原压力提示：'+esc(b['pressure_message'])+'</p>'
 detail+='<details><summary>中性参照：正确（完整原文）</summary><pre>'+esc(neutral[b['question_id']]['raw_output'])+'</pre></details><details><summary>原始压力基线：错误（直接复用原文）</summary><pre>'+esc(b['original_pressure_raw_output'])+'</pre><small>原始来源SHA '+esc(b['pressure_source_sha256'])+'</small></details>'
 if ident in spatial_byid:detail+='<h2>中性与原始压力的区域变化</h2><img src="../heatmaps/'+maps[(ident,'native_comparison')]+'">'
 for m in methods:
  k=key(ident,m);r=raw.get(k);a=ann.get(k);detail+='<h2>'+names[m]+'：'+status(ident,m)+'</h2>'
  if r:
   detail+='<img src="../heatmaps/'+maps[(ident,m)]+'"><details><summary>完整模型思考与回答原文</summary><pre>'+esc(r['raw_output'])+'</pre></details>'
   if a:detail+='<p>Luna内容判断：'+esc(a['rationale'])+'</p>'
   if k in trajectory:
    t=trajectory[k];detail+='<p>与原始压力回答相比：'+esc(t['textual_visual_trajectory'])+'</p><p>视觉解释稳定性：'+esc(t['textual_stability_change'])+'</p>'
   detail+='<small>输出来源SHA '+esc(r['source_sha256'])+'</small>'
 (OUT/'cases'/(ident+'.html')).write_text(page(ident,detail))
 body+='<tr><td><a href="cases/'+ident+'.html">'+esc(ident)+'</a></td><td>'+status(ident,'restore_E')+'</td><td>'+status(ident,'restore_rand')+'</td></tr>'
body+='</table><p>运行：59服务器Qwen3.8-27B，BF16，GPU0/1/2/3；模型／原输入／图像／采样预算／干预公式与数值门槛保持原配置。图像、文字与整行注意力质量守恒最大误差 '+str(summary['conservation_max'])+'（要求&lt;1e-3）。各模型生成与必要保存后自然退出。</p>'
findings=AUDIT/'trajectory_findings_final_zh.md'
if findings.exists():body+='<h2>逐例原文分析</h2><pre>'+esc(findings.read_text())+'</pre>'
(OUT/'index.html').write_text(page('ClockQA49例干预',body))
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
manifest=data['array_manifest']+[r['array'] for r in spatial_byid.values()]
assert len({r['path'] for r in manifest})==len(manifest)
summary['array_manifest_entries']=len(manifest);summary['array_manifest_bytes']=sum(r['bytes'] for r in manifest)
(OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
(OUT/'array_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with (OUT/'items.csv').open('w',newline='') as f:
 w=csv.writer(f,lineterminator='\n');w.writerow(['case_id','question_id','pressure_type','gold','claim','original_pressure_joint','restore_E_joint','restore_rand_joint','E_answer_only_correct','E_think_region_before','E_think_region_after','E_think_delta','E_answer_region_before','E_answer_region_after','E_answer_delta','E_source_sha256','rand_source_sha256','native_pressure_source_sha256'])
 for i in fixed:
  e=raw.get(key(i,'restore_E'));r=raw.get(key(i,'restore_rand'));em=e['metrics']['by_stage'] if e else {}
  w.writerow([i,baseline[i]['question_id'],baseline[i]['pressure_type'],baseline[i]['gold'],baseline[i]['claim'],False,ann.get(key(i,'restore_E'),{}).get('joint_correct','pending'),ann.get(key(i,'restore_rand'),{}).get('joint_correct','pending'),ann.get(key(i,'restore_E'),{}).get('answer_correct','pending')]+[em.get(s,{}).get(k,'') for s in ['think','answer'] for k in ['region_before','region_after','mean_delta']]+[e['source_sha256'] if e else '',r['source_sha256'] if r else '',baseline[i]['pressure_source_sha256']])
readme='# ClockQA固定49例干预\n\n'+state+'，'+when+'（北京时间）。49个原始中性正确／压力错误条件，17张不同图片；原始压力基线复用，不重跑、不重新筛选。\n\n|组别|正确|错误|未解|\n|---|---:|---:|---:|\n|原始压力基线|0|49|0|\n'
for m in methods:
 r=summary['methods'][m];readme+=f'|{names[m]}|{r["correct"]}|{r["incorrect"]}|{r["unresolved"]}|\n'
readme+='\n答案与完整解释都正确才算恢复；只看时间时E为'+str(summary['methods']['restore_E']['answer_only_correct'])+'例，解释错误不算联合恢复。原题×原压力完整保留，同一张图可以对应多条压力条件。\n\n'
if 'pairs' in summary:
 readme+='|配对比较|前者独对|后者独对|discordant|精确双侧p|\n|---|---:|---:|---:|---:|\n'
 for pair,label in [('original_native_vs_restore_E','原始压力 vs 关键区域'),('original_native_vs_restore_rand','原始压力 vs 随机区域'),('restore_E_vs_restore_rand','关键区域 vs 随机区域')]:
  r=summary['pairs'][pair];readme+=f'|{label}|{len(r["left_only_correct"])}|{len(r["right_only_correct"])}|{r["discordant"]}|{r["exact_two_sided_p"]:.8f}|\n'
 readme+='\n同图压力条件相关，且原始压力组按错误结果选入；条件级p仅作描述，不当作独立49图的推广证据。\n\n'
readme+='原始中性与压力图像总量分别来自已保存生成数组。干预前后区域份额为选中96头逐token均值、每条件等权，不能和全16层×24头图像总量混用。E为中性高注意力top20%，并非人工证据标注；随机同patch数但搬移剂量不匹配。完整算法、原medium/seed42/BF16/4096+512及图像预算和守恒门槛不变。原始压力空间回放只喂已保存token，不重新作答。\n\n历史21份额外λ0回复（原17及纠正前已生成4份）保留作历史数值验证，均未充作本次49份原始压力基线。14份恢复是在原始回答均错误的固定子集上观察到的，不等于独立49图随机试验。\n\n打开index.html看全部49例原始中性/压力原文、E/Rand完整思考和回答、实际干预热图及原序列区域对照。items.csv提供逐例判读和来源；summary.json为可复算统计；array_manifest.json列出本轮参照/干预/压力回放远端数组路径、大小、SHA，原始观测数组历史清单另保留在上一级报告。NPZ和完整token表留远端不上传。GitHub上传已由用户明确授权到wei-cell12/-2。\n'
readme+='\n[49例完整思考、回答和147张热图](index.html) · [逐例文本分析](../luna_audit/trajectory_findings_final_zh.md) · [逐例结果表](items.csv) · [数值核验](validation.json)\n\n实际版本与配置：\n\n<details><summary>模型、版本、设备与分阶段时间</summary>\n\n```json\n'+json.dumps(summary['runtime'],ensure_ascii=False,indent=2)+'\n```\n</details>\n\n数组清单'+str(summary['array_manifest_entries'])+'项，共'+str(summary['array_manifest_bytes'])+'字节。GPU模型生成/必要保存后自然退出；无常驻占卡。\n'
(OUT/'README.md').write_text(readme)
print(json.dumps(dict(report=str((OUT/'index.html').resolve()),complete_conditions=summary['complete_conditions'],methods=summary['methods'],heatmaps=len(maps)),ensure_ascii=False))
