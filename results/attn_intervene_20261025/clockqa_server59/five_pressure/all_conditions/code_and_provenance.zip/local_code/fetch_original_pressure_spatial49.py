"""Fetch reduced exact native-pressure maps and progress, never NPZ or tokens."""
import json,subprocess,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent;OUT=BASE/'all_conditions/results'
script=r'''
import json,time
from pathlib import Path
root=Path('/mnt/sdi/linxin/proofwriter_runs/clockqa-scaleup-20261025/interventions');folder=root/'original_pressure_spatial'
selected=json.loads((root/'luna_approved_candidates.json').read_text())['items'];records=[]
for item in selected:
 p=folder/(item['id']+'.json')
 if p.exists():
  r=json.loads(p.read_text());assert r['validation']['source_record_sha256']==item['pressure_source_sha256'];assert r['saved_token_replay_only'] and not r['new_answer_generated'];records.append(r)
workers=[]
if (folder/'launch_receipt.json').exists():
 for worker in json.loads((folder/'launch_receipt.json').read_text())['workers']:
  p=Path(worker['root']);stat=Path('/proc')/str(worker['pid'])/'stat';alive=stat.exists() and stat.read_text().split(') ',1)[1][0]!='Z'
  worker.update(alive=alive,state=json.loads((p/'job_state.json').read_text()) if (p/'job_state.json').exists() else None,failure=json.loads((p/'failure.json').read_text()) if (p/'failure.json').exists() else None);workers.append(worker)
print(json.dumps(dict(snapshot_unix=time.time(),records=records,completed=len(records),target=49,workers=workers,new_baseline_answers_generated=False)))
'''
sys.path.insert(0,str(BASE.parent/'server_connection'));from transport import command
p=subprocess.run(command('python3 -'),input=script,text=True,capture_output=True,timeout=45)
if p.returncode:raise RuntimeError(p.stderr)
d=json.loads(p.stdout);OUT.mkdir(exist_ok=True);(OUT/'original_pressure_spatial.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(completed=d['completed'],workers=d['workers'],path=str(OUT/'original_pressure_spatial.json'))))
