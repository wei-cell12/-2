"""Cross-check fixed scope, source text, labels, quotes and saved-map provenance."""
import hashlib,json,math,time
from pathlib import Path
BASE=Path(__file__).resolve().parent;AUDIT=BASE/'all_conditions/luna_audit';OUT=BASE/'all_conditions/results'
def load(p):return json.loads(p.read_text())
def rows(p):return [json.loads(s) for s in p.read_text().splitlines() if s.strip()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
p=load(AUDIT/'source_snapshot.json');fixed=set(p['fixed_case_ids']);assert len(fixed)==49
raw={r['record_key']:r for r in p['records']};assert len(raw)==98
base={r['id']:r for r in p['original_pressure_baselines']};assert set(base)==fixed
neutral={r['question_id']:r for r in p['neutral_records']};assert len(neutral)==17
annotations=rows(AUDIT/'prior_34_intervention_annotations.jsonl')+rows(AUDIT/'new_intervention_annotations.jsonl');ann={r['record_key']:r for r in annotations};assert len(ann)==len(annotations)==98
for k,a in ann.items():
 r=raw[k];b=base[r['id']];assert r['id'] in fixed and r['pressure_text']==b['pressure_message']
 assert hashlib.sha256(r['raw_output'].encode()).hexdigest()==r['raw_output_sha256']
 for f in ['source_sha256','raw_output_sha256','image_sha256']:assert a[f]==r[f]
 assert r['image_sha256']==b['image_sha256'] and a['model']=='gpt-6-luna'
 source_relative=Path(r['source_path']).relative_to('/mnt/sdi/linxin/proofwriter_runs/clockqa-scaleup-20261025/interventions')
 source_lines=(BASE/'all_conditions/remote_receipts'/source_relative).read_text().splitlines();source_line=source_lines[r['source_line']-1]
 assert hashlib.sha256(source_line.encode()).hexdigest()==r['source_sha256']
 full=json.loads(source_line);assert full['raw_output']==r['raw_output'] and full['message']==r['pressure_text'] and full['source_input_sha256']==b['pressure_source_sha256']
 expected=False if a['answer_correct'] is False or a['explanation_correct'] is False else True if a['answer_correct'] is True and a['explanation_correct'] is True else None
 assert a['joint_correct'] is expected,(k,'inconsistent joint label')
 for q in [a['final_answer_quote']]+a['explanation_quotes']:assert q in r['raw_output']
 m=r['metrics'];assert all(m[f]<1e-3 for f in ['image_diff_max','text_diff_max','row_diff_max']);assert not m['prefill_intervened'] and m['active_head_tokens']>0 and m['region_after']>m['region_before']
trajectory=rows(AUDIT/'trajectory_annotations.jsonl');assert len({t['record_key'] for t in trajectory})==len(trajectory)==98
quotes=0
for t in trajectory:
 k=t['record_key'];r=raw[k];b=base[r['id']];n=neutral[r['question_id']]
 assert t['case_id']==r['id'] and t['method']==r['method'] and t['baseline_kind']=='original_native_pressure' and not t['baseline_generated_now']
 assert t['intervention']['joint_correct'] is ann[k]['joint_correct']
 for part,text,source,rawhash in [('native_pressure',b['original_pressure_raw_output'],b['pressure_source_sha256'],b['pressure_raw_output_sha256']),('neutral',n['raw_output'],n['source_sha256'],n['raw_output_sha256']),('intervention',r['raw_output'],r['source_sha256'],r['raw_output_sha256'])]:
  entry=t[part];assert entry['source_sha256']==source and entry['raw_output_sha256']==rawhash
  q=entry['final_quote'];assert text[q['char_offset_start']:q['char_offset_end']]==q['quote'];assert hashlib.sha256(q['quote'].encode()).hexdigest()==q['quote_sha256'];quotes+=1
d=load(OUT/'derived_attention.json');spatial=load(OUT/'original_pressure_spatial.json')
assert len(d['cases'])==49 and d['source_snapshot_sha256']==sha(AUDIT/'source_snapshot.json')
assert len(spatial['records'])==49 and all(not w['alive'] and w['state']['model_released'] and not w['failure'] for w in spatial['workers'])
for r in spatial['records']:
 c=r['validation'];assert c['ok'] and c['source_record_sha256']==base[r['id']]['pressure_source_sha256'] and c['selfcheck_max']<.05 and c['corr']>=.99 and c['mad']<=.01
 assert r['saved_token_replay_only'] and not r['new_answer_generated']
 for s in ['think','answer']:
  a=r['stages'][s]
  if a['available']:
   for kind in ['neutral_map','pressure_map']:assert all(math.isfinite(x) and x>=0 for x in a[kind]) and abs(sum(a[kind])-1)<1e-6
summary=load(OUT/'summary.json');assert summary['report_complete']
assert summary['methods']['restore_E']['correct']==14 and summary['methods']['restore_rand']['correct']==4
assert len(list((OUT/'heatmaps').glob('*.png')))==147 and len(list((OUT/'cases').glob('*.html')))==49
result=dict(ok=True,fixed_conditions=49,unique_images=17,original_baselines_reused=49,intervention_outputs=98,annotations=98,trajectories=98,final_quotes_checked=quotes,original_spatial_replays=49,heatmaps=147,own_models_released=True,snapshot_sha256=sha(AUDIT/'source_snapshot.json'),trajectory_sha256=sha(AUDIT/'trajectory_annotations.jsonl'),summary_sha256=sha(OUT/'summary.json'),time_unix=time.time())
(OUT/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result))
