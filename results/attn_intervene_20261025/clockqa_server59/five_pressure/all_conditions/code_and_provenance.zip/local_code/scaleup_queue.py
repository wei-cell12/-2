"""Finite four-worker pressure queue. Eligibility is left to the same Luna."""
import contextlib, fcntl, json, os, time
from pathlib import Path

PARENT = Path(os.environ.get('CLOCKQA_PARENT_ROOT', Path(__file__).resolve().parent))

def write(path, value):
    tmp = path.with_name(path.name + '.tmp.' + str(os.getpid()))
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    tmp.replace(path)

@contextlib.contextmanager
def locked():
    with (PARENT / 'queue.lock').open('a') as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        value = json.loads((PARENT / 'queue.json').read_text())
        yield value
        value['updated_unix'] = time.time()
        write(PARENT / 'queue.json', value)

def claim(worker):
    with locked() as q:
        if q.get('failure'):
            raise RuntimeError('Saved failure requires diagnosis: ' + str(q['failure']))
        for ident in q['order']:
            entry = q['entries'][ident]
            if entry['status'] == 'pending':
                entry.update(status='running', owner=worker, claimed_unix=time.time())
                return ident
        return None

def complete(worker, ident, path):
    import hashlib
    with locked() as q:
        e = q['entries'][ident]
        assert e['status'] == 'running' and e['owner'] == worker
        body = path.read_bytes()
        row = json.loads(body)
        assert row['record_id'] == ident + '__pressure'
        e.update(status='complete', source_record=str(path),
                 source_sha256=hashlib.sha256(body).hexdigest(),
                 raw_output_sha256=hashlib.sha256(row['raw_output'].encode()).hexdigest(),
                 completed_unix=time.time())

def fail(worker, error):
    with locked() as q:
        q['failure'] = dict(worker=worker, error=repr(error), time_unix=time.time())

def finished(worker):
    with locked() as q:
        q.setdefault('exited_workers', [])
        if worker not in q['exited_workers']:
            q['exited_workers'].append(worker)
        if len(q['exited_workers']) == 4:
            assert all(x['status'] == 'complete' for x in q['entries'].values())
            write(PARENT / 'job_state.json', dict(
                status='pressure_generation_complete_awaiting_same_luna',
                pressure_conditions=310, unique_questions=62,
                reused_neutral_records=62, reused_pressure_records=62,
                newly_generated_pressure_records=248,
                all_four_model_processes_finishing=True,
                intervention_target_unique_questions=20,
                full_intervention_complete=False, time_unix=time.time()))

def selftest():
    """Exercise queue exclusivity with four actual CPU processes."""
    import multiprocessing, tempfile
    global PARENT
    previous = PARENT
    with tempfile.TemporaryDirectory() as directory:
        PARENT = Path(directory)
        write(PARENT / 'queue.json', dict(order=[str(i) for i in range(32)],
              entries={str(i): dict(status='pending') for i in range(32)}))
        def run(index):
            got = []
            while True:
                ident = claim(index)
                if ident is None:
                    break
                got.append(ident)
            (PARENT / ('claims_' + str(index) + '.json')).write_text(json.dumps(got))
        context = multiprocessing.get_context('fork')
        children = [context.Process(target=run, args=(i,)) for i in range(4)]
        for child in children: child.start()
        for child in children:
            child.join(20)
            assert child.exitcode == 0
        claimed = sum([json.loads((PARENT / ('claims_' + str(i) + '.json')).read_text()) for i in range(4)], [])
        assert len(claimed) == len(set(claimed)) == 32
        assert claim(0) is None
    PARENT = previous
    return dict(passed=True, cpu_processes=4, unique_claims=32, duplicate_claims=0)

