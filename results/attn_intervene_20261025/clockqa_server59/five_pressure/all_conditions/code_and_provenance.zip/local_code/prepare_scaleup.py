"""Validate immutable source reuse and tokenize all five pressure templates on CPU."""
import hashlib, json, os
from pathlib import Path
import generation_common as g
import workflow_common as w

ROOT = Path(__file__).resolve().parent

def main():
    c = w.config()
    assert w.sha(ROOT / 'catalog.jsonl') == c['catalog_sha256']
    assert c['questions'] == 62 and c['pressure_conditions'] == 310
    source = Path(c['prior_experiment_root'])
    assert w.sha(source / 'config.json') == c['prior_config_sha256']
    identity = Path(c['model_identity_root']) / 'model_identity.json'
    assert w.sha(identity) == c['model_identity_sha256']
    ident = json.loads(identity.read_text())
    for name, digest in ident['metadata_sha256'].items():
        assert w.sha(Path(c['model_dir']) / name) == digest
    for weight in ident['weight_files']:
        st = (Path(c['model_dir']) / weight['name']).stat()
        assert (st.st_size, st.st_mtime_ns) == (weight['bytes'], weight['mtime_ns'])
    processor = g.processor_for(c)
    catalog = w.catalog()
    assert len(catalog) == len({r['item_id'] for r in catalog}) == 310
    assert len({r['question_id'] for r in catalog}) == 62
    assert all(sum(r['question_id'] == q for r in catalog) == 5 for q in {r['question_id'] for r in catalog})
    frozen, reused = [], []
    for item in catalog:
        assert w.sha(ROOT / item['image_path']) == item['image_sha256']
        assert item['pressure_text'] == c['pressure_templates'][item['pressure_type']].format(wrong=item['wrong_answer'])
        batch, entry = g.prepare(item, 'pressure', processor, c)
        assert len(entry['prefill_query_indices']) <= 1024, 'Storage bound must be recomputed before launch'
        frozen.append(entry)
        del batch
        old = source / 'records' / (item['question_id'] + '__pressure') / 'record.json'
        oldrow = json.loads(old.read_text())
        if item['pressure_type'] == oldrow['pressure_type']:
            assert entry['input_ids'] == oldrow['input_ids']
            assert entry['image_sha256'] == oldrow['image_sha256']
            assert entry['pressure_insert'] == oldrow['pressure_insert']
            reused.append(dict(case_id=item['item_id'], source_record=str(old), source_sha256=w.sha(old)))
    assert len(reused) == 62
    neutrals = []
    for question in sorted({r['question_id'] for r in catalog}):
        original = source / 'records' / (question + '__neutral') / 'record.json'
        row = json.loads(original.read_text())
        item = next(r for r in catalog if r['question_id'] == question)
        batch, entry = g.prepare(item, 'neutral', processor, c)
        assert entry['input_ids'] == row['input_ids']
        assert entry['image_sha256'] == row['image_sha256']
        del batch
        neutrals.append(dict(question_id=question, source_record=str(original), source_sha256=w.sha(original),
                             raw_output_sha256=hashlib.sha256(row['raw_output'].encode()).hexdigest()))
    body = ''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in frozen)
    dest = ROOT / 'tokenized_inputs.jsonl'
    if dest.exists(): assert dest.read_text() == body
    else: dest.write_text(body)
    w.write(ROOT / 'neutral_sources.json', neutrals)
    w.write(ROOT / 'reused_pressure_sources.json', reused)
    import scaleup_queue
    test = scaleup_queue.selftest()
    w.write(ROOT / 'cpu_preflight.json', dict(
        passed=True, unique_questions=62, pressure_conditions=310,
        unchanged_neutral_inputs=62, unchanged_reused_pressure_inputs=62,
        new_pressure_conditions=248, unchanged_image_bytes=True,
        per_question_claim_fixed_across_five_templates=True,
        tokenized_sha256=w.sha(dest), config_sha256=w.sha(ROOT / 'config.json'),
        queue_test=test, semantic_screening='same Luna; no automatic eligibility'))
    print(json.dumps(json.loads((ROOT / 'cpu_preflight.json').read_text())), flush=True)

if __name__ == '__main__': main()
