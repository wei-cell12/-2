"""Finish a prepared two-arm handoff after asynchronous CUDA context release."""
import subprocess,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent
SCRIPT=r'''
import fcntl,hashlib,json,os,shutil,subprocess,time
from pathlib import Path
r=Path('/mnt/sdi/linxin/proofwriter_runs/clockqa-scaleup-20261025/interventions');t=r.parent/'intervention_transition'
def alive(pid):
 p=Path('/proc')/str(pid)/'stat'
 return p.exists() and p.read_text().split(') ',1)[1][0]!='Z'
def write(p,x):
 n=p.with_name(p.name+'.next');n.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');n.replace(p)
with (r/'launch.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not (r/'launch_receipt.json').exists()
 cfg=json.loads((r/'config.json').read_text());assert cfg['intervention_methods']==['restore_E','restore_rand']
 q=json.loads((r/'queue.json').read_text());assert not q.get('failure') and all(x['status']=='complete' for x in q['interventions'].values())
 selection=json.loads((r/'luna_approved_candidates.json').read_text());assert len(selection['items'])==49
 assert len(json.loads((r/'original_pressure_baselines.json').read_text())['items'])==49
 archive=r/'attempts'/('cuda_context_release_handoff_'+str(time.time_ns()));archive.mkdir(parents=True)
 holder=json.loads((t/'temporary_reservation_state.json').read_text())
 if alive(holder['pid']):
  proc=Path('/proc')/str(holder['pid']);assert proc.stat().st_uid==os.getuid()
  assert 'intervention_transition_reservation.py' in (proc/'cmdline').read_bytes().replace(b'\0',b' ').decode()
  (t/'release_temporary_reservation').touch();deadline=time.time()+20
  while alive(holder['pid']):
   assert time.time()<deadline,'Temporary holder has not naturally exited'
   time.sleep(.2)
 # /proc exit can precede NVML context release; wait for both memory and process lists.
 deadline=time.time()+45
 while True:
  inv=subprocess.run(['nvidia-smi','--query-gpu=index,uuid,memory.used,memory.free,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=15,check=True).stdout
  cards={int(a[0]):a for line in inv.splitlines() if len(a:=[x.strip() for x in line.split(',')])==5 and a[0].isdigit()}
  apps=subprocess.run(['nvidia-smi','--query-compute-apps=gpu_uuid,pid','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=15,check=True).stdout
  busy={line.split(',')[0].strip() for line in apps.splitlines() if line.strip()}
  if all(i in cards and int(cards[i][2])<=1024 and int(cards[i][3])>=73728 and int(cards[i][4])==0 and cards[i][1] not in busy for i in range(4)):break
  assert time.time()<deadline,'Four authorized cards not all fully released; no other process touched'
  time.sleep(1)
 t.rename(archive/'prior_finite_reservation');t.mkdir();(t/'intervention_transition_reservation.py').write_text(RESERVATION_CODE)
 runtime='/home/linxin/miniconda3/envs/vllm_new/bin/python'
 result=subprocess.run([runtime,str(t/'intervention_transition_reservation.py')],capture_output=True,text=True,timeout=75)
 (archive/'reservation_receipt.txt').write_text(result.stdout+result.stderr);assert result.returncode==0,result.stderr
 holder=json.loads((t/'temporary_reservation_state.json').read_text());assert holder['status']=='reserved' and {x['index'] for x in holder['cards']}=={0,1,2,3}
 cfg['transition_deadline_unix']=holder['deadline'];write(r/'config.json',cfg);write(r/'request.json',cfg)
 gate=json.loads((r/'cpu_preflight.json').read_text());gate['config_sha256']=hashlib.sha256((r/'config.json').read_bytes()).hexdigest();write(r/'cpu_preflight.json',gate)
 for i in range(4):
  for n in ['config.json','request.json','cpu_preflight.json']:shutil.copy2(r/n,r/'workers'/str(i)/n)
 write(r/'original_baseline_reuse_receipt.json',dict(original_conditions=49,methods=['restore_E','restore_rand'],completed_intervention_conditions_reused=len(q['interventions']),remaining_conditions=49-len(q['interventions']),baseline_regeneration_disabled=True,healthy_models_not_interrupted=True,time_unix=time.time()))
print(json.dumps(dict(prepared=True,conditions=49,complete=len(q['interventions']),remaining=49-len(q['interventions']),methods=cfg['intervention_methods'])),flush=True)
result=subprocess.run([runtime,str(r/'launch_clock_interventions.py')],cwd=r,capture_output=True,text=True,timeout=90)
print(result.stdout);print(result.stderr);raise SystemExit(result.returncode)
'''
def main():
 script=SCRIPT.replace('RESERVATION_CODE',repr((BASE/'intervention_transition_reservation.py').read_text()));compile(script,'remote_two_arm_handoff','exec')
 sys.path.insert(0,str(BASE.parent/'server_connection'));from transport import command
 p=subprocess.run(command('python3 -'),input=script,text=True,capture_output=True,timeout=230)
 (BASE/'two_arm_launch_receipt.txt').write_text(p.stdout+p.stderr);print(p.stdout);print(p.stderr);raise SystemExit(p.returncode)
if __name__=='__main__':main()
