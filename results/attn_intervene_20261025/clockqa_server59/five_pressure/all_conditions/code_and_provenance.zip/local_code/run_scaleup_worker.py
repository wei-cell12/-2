"""One finite model worker; shared immutable sources, distinct new pressure records."""
import fcntl, gc, json, os, subprocess, sys, time, traceback
from pathlib import Path
from workflow_common import *
import scaleup_queue as queue

PARENT = queue.PARENT

def release_ready_holder(worker):
    if worker == 3:
        (PARENT / 'reservation_gpu3' / 'release_temporary_reservation').touch()
    elif all((PARENT / 'workers' / str(i) / 'model_ready.json').exists() for i in range(3)):
        (PARENT / 'release_temporary_reservation').touch()

def verify_resources():
    allocation = json.loads((ROOT / 'allocation_request.json').read_text())
    card = allocation['physical_gpus'][0]
    assert card in [0, 1, 2, 3] and len(allocation['uuids']) == 1
    expected = allocation['uuids'][0]
    inventory = subprocess.run(['nvidia-smi', '--query-gpu=index,uuid,memory.used,memory.free,utilization.gpu',
        '--format=csv,noheader,nounits'], capture_output=True, text=True, check=True, timeout=20).stdout
    rows = [[x.strip() for x in line.split(',')] for line in inventory.splitlines()]
    row = next(r for r in rows if int(r[0]) == card)
    assert row[1] == expected and int(row[2]) <= 1024 and int(row[3]) >= 73728, row
    apps = subprocess.run(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid', '--format=csv,noheader,nounits'],
        capture_output=True, text=True, check=True, timeout=20).stdout
    allowed = set(allocation['temporary_holder_pids']) | {os.getpid()}
    assert all(int(line.split(',')[1]) in allowed for line in apps.splitlines() if line.split(',')[0].strip() == expected), apps
    write(ROOT / 'pre_model_resource_check.json', dict(card=card, uuid=expected, row=row, allowed_own_holder_pids=list(allowed), time_unix=time.time()))

def main():
    worker = int(os.environ['CLOCKQA_WORKER_INDEX'])
    sys.path.insert(0, str(ROOT / 'source'))
    c = config()
    gate = json.loads((ROOT / 'cpu_preflight.json').read_text())
    assert gate['passed'] and gate['config_sha256'] == sha(ROOT / 'config.json')
    assert c['sdpa_decode_kernel'] == 'math' and c['thinking_budget'] == 4096 and c['answer_budget'] == 512
    frozen = {r['record_id']: r for r in readlines(ROOT / 'tokenized_inputs.jsonl')}
    verify_resources()
    from observe import Observer
    from screening import generate_one
    observer = Observer(c['layers'], c['heads'], c['prefill_query_chunk'])
    b = backend(observer)
    write(ROOT / 'model_ready.json', dict(pid=os.getpid(), worker=worker, physical_gpu=worker, time_unix=time.time()))
    release_ready_holder(worker)
    byid = {r['item_id']: r for r in catalog()}
    completed = []
    while True:
        ident = queue.claim(worker)
        if ident is None: break
        item = byid[ident]
        generate_one(b, observer, item, 'pressure', frozen[ident + '__pressure'])
        queue.complete(worker, ident, ROOT / 'records' / (ident + '__pressure') / 'record.json')
        completed.append(ident)
        state('pressure_case_saved', worker=worker, case_id=ident, completed_new_conditions=len(completed))
    observer.active = False
    del b
    gc.collect()
    import torch
    torch.cuda.empty_cache()
    state('worker_complete', worker=worker, newly_generated=len(completed), model_released=True)
    queue.finished(worker)

if __name__ == '__main__':
    with (ROOT / 'runner.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try: main()
        except BaseException as error:
            write(ROOT / 'failure.json', dict(error=repr(error), time_unix=time.time()))
            (ROOT / 'failure_traceback.log').write_text(traceback.format_exc())
            state('failed', error=repr(error))
            queue.fail(int(os.environ['CLOCKQA_WORKER_INDEX']), error)
            (PARENT / 'release_temporary_reservation').touch()
            (PARENT / 'reservation_gpu3' / 'release_temporary_reservation').touch()
            raise
