"""One finite, explicitly authorized GPU reservation for ClockQA migration."""
import argparse,json,os,subprocess,sys,time,traceback
from pathlib import Path
ROOT=Path('/mnt/sdi/linxin/proofwriter_runs/clockqa-scaleup-20261025/intervention_transition')
def write(n,d):
 ROOT.mkdir(parents=True,exist_ok=True);p=ROOT/n;t=p.with_name(p.name+'.tmp.'+str(os.getpid()));t.write_text(json.dumps(d,indent=2)+'\n');t.replace(p)
def inventory():
 q=subprocess.run(['nvidia-smi','--query-gpu=index,uuid,memory.used,memory.free,utilization.gpu','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=20,check=True)
 cards={}
 for line in q.stdout.splitlines():
  a=[x.strip() for x in line.split(',')]
  try:cards[int(a[0])]=dict(index=int(a[0]),uuid=a[1],used=int(a[2]),free=int(a[3]),util=int(a[4]))
  except (ValueError,IndexError):continue
 q=subprocess.run(['nvidia-smi','--query-compute-apps=gpu_uuid,pid','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=20,check=True)
 busy=set()
 for line in q.stdout.splitlines():
  a=[x.strip() for x in line.split(',')]
  if len(a)==2 and a[1].isdigit() and int(a[1])!=os.getpid():busy.add(a[0])
 return cards,busy
def alive(pid):
 p=Path('/proc')/str(pid)/'stat'
 return p.exists() and p.read_text().split(') ',1)[1][0]!='Z'
def holder(cards):
 import torch
 blocks=[];small=[];started=time.time();deadline=started+7200
 try:
  assert torch.cuda.device_count()==len(cards)
  for i,card in enumerate(cards):
   torch.cuda.set_device(i);torch.cuda.init()
   rows,busy=inventory();r=rows[card['index']]
   assert r['uuid']==card['uuid'] and r['uuid'] not in busy and r['used']<=1024 and r['free']>=73728,('Card no longer idle',r)
   free,total=torch.cuda.mem_get_info(i);n=min(int(free)-2*1024**3,int(total*.94))
   assert n>=40*1024**3
   small.append(torch.empty(16*1024**2,dtype=torch.uint8,device=i))
   blocks.append(torch.empty(n-16*1024**2,dtype=torch.uint8,device=i))
  write('temporary_reservation_state.json',dict(status='reserved',pid=os.getpid(),cards=cards,bytes=[x.numel()+y.numel() for x,y in zip(blocks,small)],started=started,deadline=deadline,release_rule='model-memory handoff; exit on model-ready release flag or 2h deadline; no experiment-end holder'))
  while time.time()<deadline:
   if (ROOT/'release_temporary_reservation').exists():break
   if blocks and (ROOT/'handoff_reservation_memory').exists():
    blocks.clear();torch.cuda.empty_cache();write('temporary_reservation_state.json',dict(status='handoff_small_context_only',pid=os.getpid(),cards=cards,bytes_per_gpu=16*1024**2,deadline=deadline))
   time.sleep(2)
  blocks.clear();small.clear();torch.cuda.empty_cache();write('temporary_reservation_state.json',dict(status='released',pid=os.getpid(),time_unix=time.time()))
 except BaseException as e:
  write('temporary_reservation_state.json',dict(status='failed',pid=os.getpid(),error=repr(e),traceback=traceback.format_exc(),time_unix=time.time()));raise

def main():
 import fcntl
 ROOT.mkdir(parents=True,exist_ok=True)
 with (ROOT/'temporary_reservation.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
  p=ROOT/'temporary_reservation_launch.json'
  if p.exists():
   old=json.loads(p.read_text())
   if alive(old['pid']):print(json.dumps(dict(status='already_running',**old)));return
  assert not (ROOT/'release_temporary_reservation').exists(),'Prior release marker requires deliberate fresh-attempt handling'
  rows,busy=inventory();cards=sorted([r for i,r in rows.items() if i in [0,1,2,3] and r['uuid'] not in busy and r['used']<=1024 and r['free']>=73728 and r['util']==0],key=lambda r:(-r['free'],r['index']))[:4]
  if not cards:
   print(json.dumps(dict(status='no_healthy_wholly_idle_candidate',cards=rows)));return
  env=os.environ.copy();env['CUDA_VISIBLE_DEVICES']=','.join(r['uuid'] for r in cards)
  probe=subprocess.run([sys.executable,'-c','import torch; torch.cuda.init(); assert torch.cuda.device_count()>0; print("CUDA_OK")'],env=env,capture_output=True,text=True,timeout=25)
  assert probe.returncode==0,('CUDA health failed',probe.stderr[-1500:])
  # Holder performs the final idle/process recheck immediately before allocation.
  log=ROOT/'temporary_reservation.log'
  with log.open('ab') as f:proc=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--holder',json.dumps(cards)],env=env,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  receipt=dict(pid=proc.pid,cards=cards,deadline=time.time()+7200,log=str(log));write('temporary_reservation_launch.json',receipt)
  for _ in range(150):
   p=ROOT/'temporary_reservation_state.json'
   if p.exists():
    s=json.loads(p.read_text())
    if s.get('pid')==proc.pid and s.get('status') in ['reserved','failed']:print(json.dumps(s));return
   if proc.poll() is not None:raise RuntimeError('Reservation child exited: '+log.read_text()[-1500:])
   time.sleep(.2)
  print(json.dumps(dict(status='starting_not_yet_verified',**receipt)))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--holder');a=p.parse_args()
 if a.holder:holder(json.loads(a.holder))
 else:main()
