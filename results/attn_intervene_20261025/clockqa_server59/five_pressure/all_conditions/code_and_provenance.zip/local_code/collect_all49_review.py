"""Freeze saved intervention outputs; original pressure baselines stay immutable."""
import hashlib,json,subprocess,sys,time
from pathlib import Path
BASE=Path(__file__).resolve().parent;AUDIT=BASE/'all_conditions/luna_audit';AUDIT.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def readrows(p):return [json.loads(x) for x in Path(p).read_text().splitlines() if x.strip()]
SCRIPT=r'''
import hashlib,json,time
from pathlib import Path
root=Path('/mnt/sdi/linxin/proofwriter_runs/clockqa-scaleup-20261025/interventions');known=KNOWN;fixed=FIXED;out=[];counts={}
for method in ['restore_E','restore_rand']:
 seen=set()
 for i in range(4):
  p=root/'workers'/str(i)/'runs'/method/'final.jsonl'
  if not p.exists():continue
  for number,line in enumerate(p.read_text().splitlines(),1):
   if not line.strip():continue
   r=json.loads(line);ident=r['id'];assert ident in fixed and ident not in seen;seen.add(ident)
   item=fixed[ident];assert r['method']==method and r['ptype']==item['ptype'] and r['message']==item['pressure_message']
   assert r['source_input_sha256']==item['pressure_source_sha256']
   key='clockqa5_intervention:'+ident+'__'+method;source=hashlib.sha256(line.encode()).hexdigest()
   if key in known:assert known[key]==source;continue
   image=root/'images'/(item['question_id']+'.jpg');assert hashlib.sha256(image.read_bytes()).hexdigest()==item['image_sha256']
   m=r['metrics'];assert all(m[k]<1e-3 for k in ['image_diff_max','text_diff_max','row_diff_max'])
   assert m['active_head_tokens']>0 and m['region_after']>m['region_before']
   out.append(dict(record_key=key,id=ident,question_id=item['question_id'],condition='pressure',method=method,pressure_type=r['ptype'],source_path=str(p),source_line=number,source_sha256=source,source_hash_definition='UTF-8 original JSONL line without newline',raw_output=r['raw_output'],raw_output_sha256=hashlib.sha256(r['raw_output'].encode()).hexdigest(),thinking=r['thinking'],final_answer=r['reply'],question=r['question'],gold=r['gold'],claim=r['claim'],pressure_text=r['message'],image_sha256=item['image_sha256'],metrics=m,trace_path=r['trace_path'],trace_sha256=r['trace_sha256'],seconds=r['seconds'],normality_checks=r['normality_checks']))
 counts[method]=len(seen)
q=json.loads((root/'queue.json').read_text());assert not q.get('failure')
workers=[]
for i in range(4):
 w=root/'workers'/str(i);state=json.loads((w/'job_state.json').read_text()) if (w/'job_state.json').exists() else None
 receipt=json.loads((w/'launch_receipt.json').read_text()) if (w/'launch_receipt.json').exists() else {};pid=receipt.get('pid',state.get('pid') if state else None)
 proc=Path('/proc')/str(pid)/'stat';alive=proc.exists() and proc.read_text().split(') ',1)[1][0]!='Z'
 failure=json.loads((w/'failure.json').read_text()) if (w/'failure.json').exists() else None
 assert failure is None,failure
 workers.append(dict(worker=i,gpu=i,pid=pid,alive=alive,state=state,failure=failure))
print(json.dumps(dict(records=out,snapshot_unix=time.time(),saved=counts,workers=workers,queue_failure=q.get('failure'),complete_conditions=sum(e['status']=='complete' for e in q['interventions'].values()))))
'''
def main():
 dest=AUDIT/'source_snapshot.json';packet=json.loads(dest.read_text()) if dest.exists() else dict(dataset='clockqa',scope='all49 fixed exact original pressure conditions; original native baselines reused; E/rand only',version=0,records=[])
 known={r['record_key']:r['source_sha256'] for r in packet['records']}
 selection=json.loads((BASE/'clock_intervention_candidates.json').read_text());fixed={r['id']:r for r in selection['items']};assert len(fixed)==49
 sys.path.insert(0,str(BASE.parent/'server_connection'));from transport import command
 script=SCRIPT.replace('KNOWN',repr(known)).replace('FIXED',repr(fixed))
 p=subprocess.run(command('python3 -'),input=script,text=True,capture_output=True,timeout=45)
 if p.returncode:raise RuntimeError(p.stderr)
 incoming=json.loads(p.stdout)
 progress={k:v for k,v in incoming.items() if k!='records'}
 progress.update(fixed_conditions=49,baseline_policy='reuse_original_native_pressure',methods=['restore_E','restore_rand'])
 (BASE/'latest_all49_progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2)+'\n')
 status_path=BASE/'execution_status.json';status=json.loads(status_path.read_text())
 status.update(snapshot_unix=incoming['snapshot_unix'],current_phase='two_arm_generation' if any(w['alive'] for w in incoming['workers']) else 'generation_saved_models_exited',intervention_conditions_completed=incoming['complete_conditions'],remaining_intervention_conditions=49-incoming['complete_conditions'],intervention_replies_completed=sum(incoming['saved'].values()),remaining_intervention_replies=98-sum(incoming['saved'].values()),current_workers=incoming['workers'],models_released=not any(w['alive'] for w in incoming['workers']))
 status_path.write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n')
 for r in incoming['records']:
  image=BASE/'luna_audit/images'/(r['question_id']+'.jpg');assert sha(image)==r['image_sha256'];r['local_image_path']=str(image.resolve())
  assert hashlib.sha256(r['raw_output'].encode()).hexdigest()==r['raw_output_sha256']
 old_annotations=[r for r in readrows(BASE/'luna_audit/intervention_effect_annotations_resolved_v3.jsonl') if r['method'] in ['restore_E','restore_rand']]
 assert len(old_annotations)==34
 prior=AUDIT/'prior_34_intervention_annotations.jsonl'
 if not prior.exists():prior.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in old_annotations))
 reviewed={r['record_key']:r for r in old_annotations}
 new_annotations=AUDIT/'new_intervention_annotations.jsonl'
 if new_annotations.exists():
  for r in readrows(new_annotations):
   assert r['record_key'] not in reviewed;reviewed[r['record_key']]=r
 records=packet['records']+incoming['records'];bykey={r['record_key']:r for r in records};assert len(bykey)==len(records)
 for key,a in reviewed.items():
  if key not in bykey:continue
  r=bykey[key]
  if a['joint_correct'] is True:assert a['answer_correct'] is True and a['explanation_correct'] is True,('Inconsistent joint annotation',key)
  for field in ['source_sha256','raw_output_sha256','image_sha256']:assert a[field]==r[field]
  for quote in [a['final_answer_quote']]+a['explanation_quotes']:assert quote in r['raw_output']
 if dest.exists() and not incoming['records']:
  print(json.dumps(dict(new_records=0,saved_outputs=len(records),reviewed_outputs=len(reviewed),complete_conditions=incoming['complete_conditions'])));return
 if dest.exists():
  h=AUDIT/'history';h.mkdir(exist_ok=True);old=h/('source_snapshot_v'+str(packet['version'])+'.json');assert not old.exists();old.write_bytes(dest.read_bytes())
 # Native original pressure outputs are the primary baseline. Historical regenerated lambda0 is excluded.
 native=readrows(BASE/'all_conditions/original_pressure_baselines.jsonl');assert len(native)==49
 s=json.loads((BASE/'luna_audit/source_snapshot.json').read_text());old=json.loads(Path(s['prior_source_snapshot']).read_text());native_records={r['record_key']:r for r in old['records']+s['records']}
 neutrals=[]
 for ident in sorted({r['neutral_record_key'] for r in native}):
  r=native_records[ident];neutrals.append(dict(record_key=ident,question_id=r['id'].split('--')[0].split('__')[0],raw_output=r['raw_output'],source_sha256=r['source_sha256'],raw_output_sha256=r['raw_output_sha256'],image_sha256=r['image_sha256']))
 packet.update(version=packet['version']+1,records=records,new_record_keys=[r['record_key'] for r in incoming['records']],needs_joint_review_keys=[r['record_key'] for r in records if r['record_key'] not in reviewed],snapshot_unix=incoming['snapshot_unix'],complete_conditions=incoming['complete_conditions'],fixed_case_ids=[r['id'] for r in selection['items']],original_pressure_baselines=native,neutral_records=neutrals,prior_intervention_annotations=str(prior.resolve()),annotation_policy=str((BASE.parent/'annotation_policy.md').resolve()),selection_sha256=sha(BASE/'clock_intervention_candidates.json'))
 dest.write_text(json.dumps(packet,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(dict(new_records=len(incoming['records']),saved_intervention_outputs=len(records),complete_conditions=incoming['complete_conditions'],joint_review_required=len(packet['needs_joint_review_keys']),path=str(dest),sha256=sha(dest))))
if __name__=='__main__':main()
