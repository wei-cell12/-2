"""Reduce saved E/rand traces on the server; copy no NPZ or token sequences."""
import hashlib,json,subprocess,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent
OUT=BASE/'all_conditions/results';OUT.mkdir(exist_ok=True)
packet_path=BASE/'all_conditions/luna_audit/source_snapshot.json'
packet=json.loads(packet_path.read_text())
specs=[{k:r[k] for k in ['id','question_id','method','trace_path','trace_sha256','metrics','seconds']} for r in packet['records']]
assert len({(r['id'],r['method']) for r in specs})==len(specs)
assert all(r['method'] in ['restore_E','restore_rand'] for r in specs)
remote=r'''
import hashlib,json,time
from pathlib import Path
import numpy as np
root=Path('/mnt/sdi/linxin/proofwriter_runs/clockqa-scaleup-20261025/interventions');specs=SPECS
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
out=dict(cases=[],array_manifest=[],snapshot_unix=time.time(),source='actual saved intervention traces, reduced on CPU; no new model inference')
for ident in sorted({s['id'] for s in specs}):
 ref=root/'references'/(ident+'.npz')
 with np.load(ref) as z:
  heads=z['heads'].astype(bool);grid=z['grid_hw'].tolist();neutral=z['E_r'].astype(float);emask=z['E_mask'].astype(bool)
 assert heads.sum()==96
 def reduce(a):
  mass=a.sum(-1);p=np.divide(a,mass[...,None],out=np.zeros_like(a),where=mass[...,None]>0)
  return [dict(map=p[s][heads].mean(0).tolist(),E_share_stage_average=float((p[s]*emask[s]).sum(-1)[heads].mean()),selected_heads_image_mass=float(mass[s][heads].mean())) for s in range(2)]
 c=dict(id=ident,question_id=ident.split('--')[0],grid_hw=grid,neutral=reduce(neutral),groups={})
 out['array_manifest'].append(dict(path=str(ref),bytes=ref.stat().st_size,sha256=sha(ref)))
 for r in [s for s in specs if s['id']==ident]:
  p=Path(r['trace_path']);assert sha(p)==r['trace_sha256']
  with np.load(p) as z:
   assert np.array_equal(z['selected_heads'].astype(bool),heads)
   c['groups'][r['method']]=dict(before=reduce(z['spatial_before'].astype(float)),after=reduce(z['spatial_after'].astype(float)),metrics=r['metrics'],seconds=r['seconds'])
  out['array_manifest'].append(dict(path=str(p),bytes=p.stat().st_size,sha256=r['trace_sha256']))
 out['cases'].append(c)
seen={r['path'] for r in out['array_manifest']}
selection=json.loads((root/'luna_approved_candidates.json').read_text())['items']
for item in selection:
 meta=json.loads((root/'reference_meta'/(item['id']+'.json')).read_text())
 p=Path(meta['source'])
 if str(p) not in seen:
  h=sha(p);assert h==meta['source_sha256'];out['array_manifest'].append(dict(path=str(p),bytes=p.stat().st_size,sha256=h,role='validated exact neutral saved-token replay'));seen.add(str(p))
 for kind in ['neutral','pressure']:
  p=Path(item[kind+'_record']);assert sha(p)==item[kind+'_source_sha256'];rec=json.loads(p.read_text());a=p.parent/'attention.npz'
  if str(a) not in seen:
   h=sha(a);assert h==rec['attention_sha256'];out['array_manifest'].append(dict(path=str(a),bytes=a.stat().st_size,sha256=h,role='original native '+kind+' saved generation'));seen.add(str(a))
out['config']=json.loads((root/'config.json').read_text());out['queue']=json.loads((root/'queue.json').read_text());out['launch']=json.loads((root/'launch_receipt.json').read_text())
out['model_allocations']=[json.loads(p.read_text()) for p in sorted((root/'workers').glob('*/latest_model_allocation.json'))]
out['pilot_gate_sha256']=sha(root/'pilot_numerical_gate.json');out['pilot_review']=json.loads((root/'pilot_review.json').read_text())
print(json.dumps(out))
'''.replace('SPECS',repr(specs))
sys.path.insert(0,str(BASE.parent/'server_connection'));from transport import command
p=subprocess.run(command('/home/linxin/miniconda3/envs/vllm_new/bin/python -'),input=remote,text=True,capture_output=True,timeout=110)
if p.returncode:raise RuntimeError(p.stderr)
out=json.loads(p.stdout)
# Native totals already derived from immutable original generation arrays; reuse them.
old=json.loads((BASE/'final_results/derived_attention.json').read_text())
lookup={r['record_key']:r for r in old['native_totals']};native=[]
for b in packet['original_pressure_baselines']:
 pair=dict(id=b['id'],question_id=b['question_id'],pressure_type=b['pressure_type'],stages={})
 for kind,key,hashkey in [('neutral','neutral_record_key','neutral_source_sha256'),('pressure','pressure_record_key','pressure_source_sha256')]:
  r=lookup[b[key]];assert r['source_sha256']==b[hashkey]
  pair[kind]=r
 native.append(pair)
assert len(native)==49
out.update(native_paired_totals=native,source_snapshot_sha256=hashlib.sha256(packet_path.read_bytes()).hexdigest(),source_snapshot_version=packet['version'],fixed_case_ids=packet['fixed_case_ids'],native_totals_source_sha256=hashlib.sha256((BASE/'final_results/derived_attention.json').read_bytes()).hexdigest())
(OUT/'derived_attention.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(saved_outputs=len(specs),cases=len(out['cases']),native_pairs=49,manifest_entries=len(out['array_manifest']),path=str(OUT/'derived_attention.json'),no_model_loaded=True,no_npz_or_tokens_transferred=True)))
