"""Collect code, metadata and finite-run logs without NPZ or full token-ID lists."""
import hashlib,json,subprocess,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent;OUT=BASE/'all_conditions/remote_receipts'
script=r'''
import hashlib,json,re
from pathlib import Path
root=Path('/mnt/sdi/linxin/proofwriter_runs/clockqa-scaleup-20261025/interventions');paths=set(root.glob('*.py'))
paths.update(root/'workers/0'/p.name for p in (root/'workers/0').glob('*.py'))
paths.update(p for p in (root/'references').glob('*.json'))
paths.update(p for p in (root/'reference_meta').glob('*.json'))
for name in ['config.json','job_state.json','queue.json','launch_receipt.json','pilot_review.json','pilot_numerical_gate.json','original_pressure_baselines.json','luna_approved_candidates.json']:paths.add(root/name)
for i in range(4):
 for folder in [root/'workers'/str(i),root/'original_pressure_spatial/workers'/str(i)]:
  paths.update((folder/'reference_meta').glob('*.json'))
  for method in ['base','restore_E','restore_rand']:
   for name in ['final.jsonl','calls.jsonl']:paths.add(folder/'runs'/method/name)
  for name in ['config.json','allocation_request.json','latest_model_allocation.json','job_state.json','runner.log','failure.json','failure_traceback.log','neutral_replay_checks.jsonl']:paths.add(folder/name)
replay=root/'original_pressure_spatial'
paths.update(replay.glob('*.json'));paths.update((replay/'arrays').glob('*_validation.json'))
files=[];omitted=[]
for p in sorted(paths):
 if not p.is_file():continue
 content=p.read_bytes();body=content.decode('utf-8');meta=dict(path=str(p.relative_to(root)),remote_path=str(p),bytes=len(content),sha256=hashlib.sha256(content).hexdigest())
 if re.search(r'["\x27](?:input_ids|output_ids|generated_ids)["\x27]\s*:\s*\[',body):omitted.append(dict(meta,reason='complete token ID arrays deliberately not transferred'));continue
 assert p.suffix in ['.py','.json','.jsonl','.log']
 files.append(dict(meta,body=body))
print(json.dumps(dict(files=files,omitted=omitted)))
'''
sys.path.insert(0,str(BASE.parent/'server_connection'));from transport import command
p=subprocess.run(command('python3 -'),input=script,text=True,capture_output=True,timeout=60)
if p.returncode:raise RuntimeError(p.stderr)
d=json.loads(p.stdout);OUT.mkdir(exist_ok=True)
for f in d['files']:
 p=OUT/f['path'];p.parent.mkdir(exist_ok=True,parents=True);assert hashlib.sha256(f['body'].encode()).hexdigest()==f['sha256'];p.write_text(f['body'])
(OUT/'manifest.json').write_text(json.dumps(dict(files=[{k:v for k,v in f.items() if k!='body'} for f in d['files']],omitted=d['omitted']),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(files=len(d['files']),bytes=sum(f['bytes'] for f in d['files']),omitted=d['omitted'])))
